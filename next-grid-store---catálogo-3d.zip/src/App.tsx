import React, { useState, useMemo, useEffect } from 'react';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { CategoryNav } from './components/CategoryNav';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { PdfCatalogModal } from './components/PdfCatalogModal';
import { Footer } from './components/Footer';
import { PRODUCTS, COMPANY_INFO } from './data/products';
import { Product, ProductCategory, CartItem } from './types';
import { CheckCircle2, Sliders } from 'lucide-react';

export default function App() {
  // Navigation & Filter States
  const [activeCategory, setActiveCategory] = useState<ProductCategory>('todos');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'relevancia' | 'menor_preco' | 'maior_preco'>('relevancia');
  const [priceFilter, setPriceFilter] = useState<'all' | 'under25' | '25to50' | 'above50'>('all');

  // Modals & Drawers
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isPdfModalOpen, setIsPdfModalOpen] = useState<boolean>(false);

  // Cart with LocalStorage persistence
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('next_grid_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Feedback states
  const [quickAddedId, setQuickAddedId] = useState<string | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem('next_grid_cart', JSON.stringify(cart));
    } catch {
      // ignore
    }
  }, [cart]);

  // Filtered and Sorted Products
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter((product) => {
      // Category check
      if (activeCategory !== 'todos' && product.category !== activeCategory) {
        if (activeCategory === 'decoracao' && product.id === 'bandeja-canelada-oval-3d') {
          // Também exibida em Decoração & Casa
        } else if (activeCategory === 'geek' && product.id === 'kit-9-enfeites-natal-harry-potter-3d') {
          // Também exibido em Geek & Games
        } else if (activeCategory === 'kits' && product.id === 'kit-9-enfeites-natal-harry-potter-3d') {
          // Também exibido em Kits & Combos
        } else {
          return false;
        }
      }

      // Search query check
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase().trim();
        const matchName = product.name.toLowerCase().includes(query);
        const matchDesc = product.description.toLowerCase().includes(query);
        const matchMaterial = product.material.toLowerCase().includes(query);
        const matchFeature = product.features.some((f) => f.toLowerCase().includes(query));
        if (!matchName && !matchDesc && !matchMaterial && !matchFeature) {
          return false;
        }
      }

      // Price filter check
      if (priceFilter === 'under25' && product.price > 25) return false;
      if (priceFilter === '25to50' && (product.price < 25 || product.price > 50)) return false;
      if (priceFilter === 'above50' && product.price <= 50) return false;

      return true;
    }).sort((a, b) => {
      if (sortBy === 'menor_preco') {
        return a.price - b.price;
      }
      if (sortBy === 'maior_preco') {
        return b.price - a.price;
      }
      // Relevância: Best sellers and featured first
      const scoreA = (a.bestSeller ? 2 : 0) + (a.isFeatured ? 1 : 0);
      const scoreB = (b.bestSeller ? 2 : 0) + (b.isFeatured ? 1 : 0);
      return scoreB - scoreA;
    });
  }, [activeCategory, searchQuery, sortBy, priceFilter]);

  // Cart Handlers
  const handleAddToCart = (newItem: Omit<CartItem, 'cartItemId'>) => {
    setCart((prevCart) => {
      const existingIdx = prevCart.findIndex(
        (i) =>
          i.product.id === newItem.product.id &&
          i.selectedOption?.name === newItem.selectedOption?.name &&
          i.selectedColor === newItem.selectedColor
      );

      if (existingIdx > -1) {
        const updated = [...prevCart];
        const current = updated[existingIdx];
        const newQty = current.quantity + newItem.quantity;
        // update unit price if bulk discount applies
        let unitPrice = newItem.unitPrice;
        if (newItem.product.bulkPrice && newQty >= newItem.product.bulkPrice.minQuantity) {
          unitPrice = newItem.product.bulkPrice.price;
        }
        updated[existingIdx] = {
          ...current,
          quantity: newQty,
          unitPrice,
        };
        return updated;
      }

      const generatedId = `${newItem.product.id}-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      return [...prevCart, { ...newItem, cartItemId: generatedId }];
    });

    triggerToast(`"${newItem.product.name}" adicionado ao carrinho!`);
  };

  const handleQuickAdd = (product: Product) => {
    handleAddToCart({
      product,
      quantity: 1,
      selectedColor: product.availableColors?.[0]?.name,
      selectedOption: product.options ? { name: product.options.choices[0].label, price: product.options.choices[0].price } : undefined,
      unitPrice: product.price,
    });

    setQuickAddedId(product.id);
    setTimeout(() => {
      setQuickAddedId(null);
    }, 1500);
  };

  const handleUpdateQuantity = (cartItemId: string, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveItem(cartItemId);
      return;
    }

    setCart((prevCart) =>
      prevCart.map((item) => {
        if (item.cartItemId === cartItemId) {
          let unitPrice = item.selectedOption?.price || item.product.price;
          if (item.product.bulkPrice && newQty >= item.product.bulkPrice.minQuantity) {
            unitPrice = item.product.bulkPrice.price;
          }
          return {
            ...item,
            quantity: newQty,
            unitPrice,
          };
        }
        return item;
      })
    );
  };

  const handleRemoveItem = (cartItemId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.cartItemId !== cartItemId));
  };

  const handleClearCart = () => {
    setCart([]);
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  const handleDirectWhatsApp = (message: string) => {
    const encoded = encodeURIComponent(message);
    window.open(`https://wa.me/${COMPANY_INFO.whatsappNumber}?text=${encoded}`, '_blank');
  };

  const cartTotal = useMemo(() => {
    return cart.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);
  }, [cart]);

  const totalItemCount = useMemo(() => {
    return cart.reduce((acc, item) => acc + item.quantity, 0);
  }, [cart]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-cyan-500/50 text-white text-xs px-4 py-3 rounded-xl shadow-2xl flex items-center gap-2.5 animate-in slide-in-from-bottom duration-200">
          <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
          <span className="font-medium">{toastMessage}</span>
        </div>
      )}

      {/* Top Header */}
      <Header
        cartItemCount={totalItemCount}
        cartTotal={cartTotal}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenPdfModal={() => setIsPdfModalOpen(true)}
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          const catalogEl = document.getElementById('catalogo');
          if (catalogEl) {
            catalogEl.scrollIntoView({ behavior: 'smooth' });
          }
        }}
        activeCategory={activeCategory}
      />

      {/* Hero Banner (Shown when not filtering search) */}
      {!searchQuery && (
        <HeroBanner
          onSelectCategory={(cat) => {
            setActiveCategory(cat);
            const catalogEl = document.getElementById('catalogo');
            if (catalogEl) {
              catalogEl.scrollIntoView({ behavior: 'smooth' });
            }
          }}
        />
      )}

      {/* Catalog Filters Bar */}
      <div id="catalogo">
        <CategoryNav
          activeCategory={activeCategory}
          onSelectCategory={setActiveCategory}
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          sortBy={sortBy}
          onSortChange={setSortBy}
          priceFilter={priceFilter}
          onPriceFilterChange={setPriceFilter}
          totalFilteredCount={filteredProducts.length}
          onOpenPdfModal={() => setIsPdfModalOpen(true)}
        />
      </div>

      {/* Main Catalog Grid Section */}
      <main className="flex-1 max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 sm:py-8 w-full">
        {filteredProducts.length === 0 ? (
          <div className="py-20 text-center max-w-md mx-auto space-y-4">
            <div className="w-14 h-14 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center mx-auto text-slate-500">
              <Sliders className="w-6 h-6 text-slate-500" />
            </div>
            <h3 className="text-lg font-bold text-white">Nenhum produto encontrado</h3>
            <p className="text-xs text-slate-400">
              Não encontramos nenhum produto correspondente aos filtros atuais. Tente buscar por outros termos ou redefinir as categorias.
            </p>
            <button
              onClick={() => {
                setActiveCategory('todos');
                setSearchQuery('');
                setPriceFilter('all');
              }}
              className="py-2 px-4 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition-colors cursor-pointer"
            >
              Ver Todo o Catálogo
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-6">
            {filteredProducts.map((product) => (
              <ProductCard
                key={product.id}
                product={product}
                onOpenDetail={setSelectedProduct}
                onQuickAdd={handleQuickAdd}
                isAddedJustNow={quickAddedId === product.id}
              />
            ))}
          </div>
        )}
      </main>

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        onDirectWhatsApp={handleDirectWhatsApp}
      />

      {/* Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
      />

      {/* PDF Catalog Modal */}
      <PdfCatalogModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        activeCategory={activeCategory}
      />

      {/* Footer */}
      <Footer
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          window.scrollTo({ top: 300, behavior: 'smooth' });
        }}
        onOpenPdfModal={() => setIsPdfModalOpen(true)}
      />
    </div>
  );
}
