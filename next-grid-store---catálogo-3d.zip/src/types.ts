export type ProductCategory = 
  | 'todos'
  | 'natal'
  | 'anime'
  | 'kits'
  | 'religioso'
  | 'decoracao'
  | 'geek'
  | 'utilidades';

export interface ProductVariant {
  id: string;
  name: string;
  priceDelta?: number; // difference from base price
  image?: string;
}

export interface Product {
  id: string;
  name: string;
  category: ProductCategory;
  price: number;
  originalPrice?: number;
  bulkPrice?: {
    minQuantity: number;
    price: number;
  };
  image: string;
  gallery?: string[];
  description: string;
  features: string[];
  dimensions?: string; // e.g. "8 x 8 x 0.4 cm"
  material: 'PLA Premium' | 'PETG Resistente' | 'Resina UV Alta Precisão' | 'Filamento Silk Dourado';
  inStock: boolean;
  isFeatured?: boolean;
  isNew?: boolean;
  bestSeller?: boolean;
  availableColors?: { name: string; hex: string }[];
  options?: {
    name: string;
    choices: { label: string; price: number }[];
  };
}

export interface CartItem {
  cartItemId: string;
  product: Product;
  quantity: number;
  selectedColor?: string;
  selectedOption?: { name: string; price: number };
  unitPrice: number;
}
