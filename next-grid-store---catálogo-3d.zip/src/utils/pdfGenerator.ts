import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { PRODUCTS, CATEGORIES, COMPANY_INFO } from '../data/products';
import { Product, ProductCategory } from '../types';

export interface GeneratePdfOptions {
  category?: ProductCategory;
  searchQuery?: string;
}

export function generateCatalogPdf(options: GeneratePdfOptions = {}): void {
  const { category = 'todos', searchQuery = '' } = options;

  // Filter products
  const productsToExport = PRODUCTS.filter((p) => {
    if (category !== 'todos' && p.category !== category) {
      if (category === 'decoracao' && p.id === 'bandeja-canelada-oval-3d') {
        // ok
      } else if (category === 'geek' && p.id === 'kit-9-enfeites-natal-harry-potter-3d') {
        // ok
      } else if (category === 'kits' && p.id === 'kit-9-enfeites-natal-harry-potter-3d') {
        // ok
      } else {
        return false;
      }
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      return (
        p.name.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q) ||
        p.material.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const categoryLabel =
    category === 'todos'
      ? 'Catálogo Geral Completo'
      : CATEGORIES.find((c) => c.id === category)?.label || 'Catálogo';

  // --- Header Page Banner ---
  doc.setFillColor(15, 23, 42); // slate-900
  doc.rect(0, 0, 210, 38, 'F');

  // Accent Line
  doc.setFillColor(6, 182, 212); // cyan-500
  doc.rect(0, 38, 210, 2, 'F');

  // Brand title
  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.text(COMPANY_INFO.name.toUpperCase(), 14, 15);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor(148, 163, 184); // slate-400
  doc.text('CATÁLOGO DE PRODUTOS EM IMPRESSÃO 3D DE ALTA RESOLUÇÃO', 14, 21);

  // Contact info on the right
  doc.setFontSize(8.5);
  doc.setTextColor(203, 213, 225);
  doc.text(`WhatsApp: ${COMPANY_INFO.whatsappFormatted}`, 196, 13, { align: 'right' });
  doc.text(`Instagram: ${COMPANY_INFO.instagramHandle}`, 196, 18, { align: 'right' });
  doc.text('5% OFF à vista via Pix · Envio para todo o Brasil', 196, 23, { align: 'right' });

  // Sub-header Info Box
  doc.setFillColor(248, 250, 252); // slate-50
  doc.rect(14, 45, 182, 14, 'F');
  doc.setDrawColor(226, 232, 240); // slate-200
  doc.rect(14, 45, 182, 14, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(10);
  doc.setTextColor(15, 23, 42);
  doc.text(`Seção: ${categoryLabel} (${productsToExport.length} itens)`, 18, 52);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(100, 116, 139);
  const dataEmissao = new Date().toLocaleDateString('pt-BR');
  doc.text(`Emitido em: ${dataEmissao} | Pedidos e orçamentos pelo WhatsApp`, 18, 56);
  doc.text(COMPANY_INFO.shipmentNotice, 192, 54, { align: 'right' });

  // Group products by category if exporting all
  const categoriesToRender: { id: string; label: string; items: Product[] }[] = [];

  if (category === 'todos') {
    CATEGORIES.filter((c) => c.id !== 'todos').forEach((cat) => {
      const items = productsToExport.filter((p) => p.category === cat.id);
      if (items.length > 0) {
        categoriesToRender.push({ id: cat.id, label: cat.label, items });
      }
    });
  } else {
    categoriesToRender.push({
      id: category,
      label: categoryLabel,
      items: productsToExport,
    });
  }

  let startY = 65;

  categoriesToRender.forEach((catSection) => {
    // Check if we need space for section header
    if (startY > 250) {
      doc.addPage();
      startY = 20;
    }

    // Section Category Title
    doc.setFillColor(241, 245, 249);
    doc.rect(14, startY - 4, 182, 7, 'F');
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor(14, 116, 144); // cyan-700
    doc.text(`• ${catSection.label.toUpperCase()} (${catSection.items.length} PRODUTOS)`, 18, startY + 1);
    startY += 8;

    // Table of products in this category
    const tableBody = catSection.items.map((prod) => {
      const pixPrice = (prod.price * 0.95).toFixed(2).replace('.', ',');
      const normalPrice = prod.price.toFixed(2).replace('.', ',');
      const bulkText = prod.bulkPrice
        ? `\n(Acima de ${prod.bulkPrice.minQuantity} un: R$ ${prod.bulkPrice.price.toFixed(2).replace('.', ',')})`
        : '';

      const featuresBrief = prod.features ? prod.features.slice(0, 2).join(' · ') : '';
      const descBrief = prod.description ? prod.description.substring(0, 110) + '...' : '';

      return [
        {
          content: `${prod.name}\n${descBrief}${featuresBrief ? '\n' + featuresBrief : ''}`,
        },
        prod.material || 'PLA Premium',
        `R$ ${normalPrice}\nPix: R$ ${pixPrice}${bulkText}`,
      ];
    });

    autoTable(doc, {
      startY: startY,
      head: [['Produto & Descrição', 'Material', 'Preço Unitário / Pix']],
      body: tableBody,
      theme: 'grid',
      headStyles: {
        fillColor: [15, 23, 42],
        textColor: [255, 255, 255],
        fontSize: 8.5,
        fontStyle: 'bold',
      },
      columnStyles: {
        0: { cellWidth: 110, fontSize: 8 },
        1: { cellWidth: 32, fontSize: 8, fontStyle: 'italic', textColor: [71, 85, 105] },
        2: { cellWidth: 40, fontSize: 8, fontStyle: 'bold', textColor: [15, 23, 42] },
      },
      styles: {
        cellPadding: 2.5,
        valign: 'middle',
        overflow: 'linebreak',
      },
      alternateRowStyles: {
        fillColor: [248, 250, 252],
      },
      margin: { left: 14, right: 14 },
      didDrawPage: () => {
        // Page footer
        const pageCount = doc.getNumberOfPages();
        doc.setFontSize(7.5);
        doc.setTextColor(148, 163, 184);
        doc.text(
          `Next Grid Store · Catálogo de Produtos 3D · WhatsApp: ${COMPANY_INFO.whatsappFormatted} · Página ${doc.getCurrentPageInfo().pageNumber}`,
          105,
          290,
          { align: 'center' }
        );
      },
    });

    const finalY = (doc as any).lastAutoTable.finalY;
    startY = finalY + 8;
  });

  // Final Notice Box at the end
  if (startY > 255) {
    doc.addPage();
    startY = 20;
  }

  doc.setFillColor(240, 253, 250); // cyan-50
  doc.rect(14, startY, 182, 18, 'F');
  doc.setDrawColor(6, 182, 212);
  doc.rect(14, startY, 182, 18, 'S');

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(8.5);
  doc.setTextColor(14, 116, 144);
  doc.text('COMO FAZER O SEU PEDIDO:', 18, startY + 5);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8);
  doc.setTextColor(51, 65, 85);
  doc.text(
    `1. Anote o nome dos produtos desejados.\n2. Envie uma mensagem pelo WhatsApp para ${COMPANY_INFO.whatsappFormatted} ou clique nos botões do site.\n3. Informe seu CEP para calcularmos o frete e enviamos fotos da sua impressão em andamento!`,
    18,
    startY + 9
  );

  // File naming
  const safeCatName = categoryLabel
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '_');
  const filename = `Catalogo_NextGridStore_${safeCatName}.pdf`;

  // Download trigger
  doc.save(filename);
}
