import { Product } from '../types';

export const CATEGORIES = [
  { id: 'todos', label: 'Todos os Produtos', count: 59 },
  { id: 'natal', label: 'Coleção de Natal', count: 11 },
  { id: 'anime', label: 'Anime & Mangá', count: 6 },
  { id: 'kits', label: 'Kits & Combos', count: 4 },
  { id: 'religioso', label: 'Arte Sacra & Religioso', count: 9 },
  { id: 'decoracao', label: 'Decoração & Casa', count: 8 },
  { id: 'geek', label: 'Geek & Games', count: 11 },
  { id: 'utilidades', label: 'Utilidades & Mesa', count: 10 },
] as const;

export const PRODUCTS: Product[] = [
  {
    id: 'bandeja-canelada-oval-3d',
    name: 'Bandeja Canelada Oval 3D',
    category: 'natal',
    price: 30.00,
    originalPrice: 42.00,
    bulkPrice: {
      minQuantity: 2,
      price: 27.00
    },
    image: '/assets/aistudio/image_8a6fe780.png',
    gallery: [
      '/assets/aistudio/image_8a6fe780.png'
    ],
    description: 'Elegante bandeja oval canelada com acabamento estriado escultural em alto relevo 3D. Perfeita para organizar a decoração natalina, servir como base para enfeites, velas aromáticas, difusores, perfumes, joias ou xícaras de café, combinando sofisticação e estilo contemporâneo.',
    features: [
      'Preço promocional: R$ 30,00',
      'Design oval contemporâneo com laterais caneladas de tendência',
      'Acabamento premium fosco em impressão 3D de alta definição',
      'Base nivelada e estável com toque suave anti-risco',
      'Produzida em PLA Premium ecológico e resistente',
      'Perfeita para mesas de Natal, aparadores, bancadas e lavabos'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    isNew: true,
    bestSeller: true,
    availableColors: [
      { name: 'Branco Neve Fosco', hex: '#f8fafc' },
      { name: 'Creme Natural Travertino', hex: '#e7dfd5' },
      { name: 'Preto Fosco Ônix', hex: '#1e293b' },
      { name: 'Dourado Champanhe Silk', hex: '#d4af37' }
    ],
    options: {
      name: 'Cor da Bandeja',
      choices: [
        { label: 'Branco Neve Fosco - R$ 30,00', price: 30.00 },
        { label: 'Creme Natural Travertino - R$ 30,00', price: 30.00 },
        { label: 'Preto Fosco Ônix - R$ 30,00', price: 30.00 },
        { label: 'Dourado Champanhe Silk - R$ 30,00', price: 30.00 }
      ]
    }
  },
  {
    id: 'boneco-de-neve-estilo-tricot-3d',
    name: 'Boneco de Neve Estilo Tricot 3D',
    category: 'natal',
    price: 35.00,
    originalPrice: 48.00,
    bulkPrice: {
      minQuantity: 2,
      price: 32.00
    },
    image: '/assets/aistudio/image_ab2c157b.png',
    gallery: [
      '/assets/aistudio/image_ab2c157b.png'
    ],
    description: 'Adorável boneco de neve decorativo com textura e acabamento escultural de tricot/crochê em 3D. Apresenta cartola preta canelada, cachecol vermelho felpudo, nariz de cenoura pontiagudo e pezinhos pretos. Perfeito para complementar a decoração de Natal em prateleiras, mesas de centro, aparadores e árvores natalinas.',
    features: [
      'Preço promocional: R$ 35,00',
      'Textura realista de ponto de lã tricotado em alto relevo 3D',
      'Cores ricas e contrastantes: cartola preta, cachecol vermelho e nariz de cenoura',
      'Impressão 3D de alta precisão em material PLA Premium resistente',
      'Peça acolhedora e charmosa para a decoração temática natalina'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    isNew: true,
    bestSeller: true,
    availableColors: [
      { name: 'Clássico (Branco com Cartola Preta e Cachecol Vermelho)', hex: '#f8fafc' },
      { name: 'Festivo (Cartola Verde e Cachecol Dourado)', hex: '#16a34a' }
    ],
    options: {
      name: 'Quantidade',
      choices: [
        { label: '1x Boneco de Neve Tricot - R$ 35,00', price: 35.00 },
        { label: 'Kit Par de Bonecos de Neve - R$ 64,00', price: 64.00 }
      ]
    }
  },
  {
    id: 'presepio-natal-tricot-3d-completo',
    name: 'Presépio de Natal Estilo Tricot 3D Completo',
    category: 'natal',
    price: 80.00,
    originalPrice: 110.00,
    bulkPrice: {
      minQuantity: 2,
      price: 75.00
    },
    image: '/assets/aistudio/image_a1648de4.png',
    gallery: [
      '/assets/aistudio/image_a1648de4.png'
    ],
    description: 'Encantador presépio natalino tridimensional com textura esculpida de tricot/crochê nos mantos e no telhado do estábulo. O conjunto acompanha o estábulo com Estrela Guia no topo, a Sagrada Família (São José, Maria e o Menino Jesus na manjedoura), os Três Reis Magos (Baltazar, Belchior e Gaspar com seus presentes) e os dóceis animaizinhos (burrinho, vaquinha, ovelha e cordeirinho). Uma peça única e acolhedora que une a modernidade da impressão 3D ao aconchego do artesanato natalino.',
    features: [
      'Preço especial de lançamento: R$ 80,00',
      'Textura realista de tricot/ponto de lã esculpida em alto relevo 3D',
      'Conjunto completo: Estábulo com Estrela + Sagrada Família + 3 Reis Magos + 4 Animais',
      'Acabamento premium em tom suave que combina com qualquer decoração de Natal',
      'Material resistente (PLA Premium ecológico) que não quebra ao cair',
      'Perfeito para aparadores, mesas de centro, lareiras e presentear'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    isNew: true,
    bestSeller: true,
    availableColors: [
      { name: 'Branco Pérola / Areia Tricot', hex: '#f1f5f9' },
      { name: 'Branco Neve Clássico', hex: '#ffffff' },
      { name: 'Marfim Acetinado', hex: '#fef08a' }
    ],
    options: {
      name: 'Composição do Presépio',
      choices: [
        { label: 'Presépio Completo Tricot (Estábulo + 10 Peças) - R$ 80,00', price: 80.00 },
        { label: 'Kit Sagrada Família Tricot (Estábulo + José, Maria e Jesus) - R$ 55,00', price: 55.00 },
        { label: 'Trio Reis Magos Tricot - R$ 40,00', price: 40.00 }
      ]
    }
  },
  {
    id: 'letreiro-feliz-natal-floco-neve-3d',
    name: 'Letreiro Escultura Feliz Natal 3D com Floco de Neve',
    category: 'natal',
    price: 40.00,
    originalPrice: 55.00,
    bulkPrice: {
      minQuantity: 2,
      price: 36.00
    },
    image: '/assets/aistudio/image_51848361.png',
    gallery: [
      '/assets/aistudio/image_51848361.png'
    ],
    description: 'Imponente letreiro de mesa escultural "Feliz Natal" esculpido em 3D com floco de neve decorativo integrado na parte superior. Possui base nivelada estável que fica em pé sozinha, ideal para mesas de ceia, aparadores, lareiras, estantes e recepções natalinas.',
    features: [
      'Preço especial: R$ 40,00',
      'Escultura 3D com tipografia encorpada e floco de neve estilizado',
      'Base estável com equilíbrio próprio sem precisar de apoio',
      'Acabamento acetinado premium em vermelho natalino marcante',
      'Produzido em PLA Premium ecológico de alta densidade e resistência',
      'Perfeito para transformar o ambiente nas festas de fim de ano'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    isNew: true,
    bestSeller: true,
    availableColors: [
      { name: 'Vermelho Natalino Clássico', hex: '#dc2626' },
      { name: 'Dourado Champanhe Silk Metálico', hex: '#d4af37' },
      { name: 'Branco Neve Fosco', hex: '#f8fafc' },
      { name: 'Verde Pinheiro Natalino', hex: '#15803d' }
    ],
    options: {
      name: 'Cor do Letreiro',
      choices: [
        { label: 'Vermelho Natalino Clássico - R$ 40,00', price: 40.00 },
        { label: 'Dourado Champanhe Silk - R$ 40,00', price: 40.00 },
        { label: 'Branco Neve Fosco - R$ 40,00', price: 40.00 },
        { label: 'Verde Pinheiro Natalino - R$ 40,00', price: 40.00 }
      ]
    }
  },
  {
    id: 'kit-9-enfeites-natal-harry-potter-3d',
    name: 'Kit 9 Enfeites de Árvore de Natal Harry Potter 3D',
    category: 'natal',
    price: 30.00,
    originalPrice: 45.00,
    bulkPrice: {
      minQuantity: 2,
      price: 27.00
    },
    image: '/assets/aistudio/image_c013ab49.png',
    gallery: [
      '/assets/aistudio/image_c013ab49.png'
    ],
    description: 'Conjunto completo com 9 enfeites colecionáveis de Natal inspirados no mundo mágico de Harry Potter vazados em impressão 3D de alta precisão. Inclui os 9 símbolos icônicos: Brasão HP clássico, Chapéu Seletor com rosto, HP com Pomo de Ouro, HP com Vassoura Nimbus, Silhueta do Chapéu Seletor, HP com Gravata Hogwarts, Símbolo das Relíquias da Morte, Plataforma 9 ¾ e Armação dos Óculos com a Cicatriz de Raio. Todos com orifício superior para pendurar na árvore de Natal.',
    features: [
      'Conjunto completo com todos os 9 enfeites temáticos de Harry Potter',
      'Preço promocional: R$ 30,00 o kit completo (apenas R$ 3,33 por enfeite!)',
      'Furos integrados para passar fita, laço ou fio natalino',
      'Design vazado com acabamento impecável e alta nitidez geométrica',
      'Material PLA Premium resistente a quedas (não quebra ao cair da árvore)',
      'Sucesso garantido para fãs da saga e decorações temáticas'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    isNew: true,
    bestSeller: true,
    availableColors: [
      { name: 'Branco Neve Fosco', hex: '#f8fafc' },
      { name: 'Dourado Champanhe Metálico', hex: '#d4af37' },
      { name: 'Preto Ônix Minimalista', hex: '#1e293b' },
      { name: 'Prata Lunar Metálico', hex: '#94a3b8' }
    ],
    options: {
      name: 'Cor do Kit',
      choices: [
        { label: 'Kit 9x Branco Neve Fosco - R$ 30,00', price: 30.00 },
        { label: 'Kit 9x Dourado Champanhe - R$ 30,00', price: 30.00 },
        { label: 'Kit 9x Preto Ônix - R$ 30,00', price: 30.00 },
        { label: 'Kit 9x Prata Lunar - R$ 30,00', price: 30.00 }
      ]
    }
  },
  {
    id: 'kit-25-enfeites-natal-flocos-neve-3d',
    name: 'Kit 25 Enfeites de Natal Flocos de Neve 3D',
    category: 'natal',
    price: 60.00,
    originalPrice: 75.00,
    bulkPrice: {
      minQuantity: 2,
      price: 55.00
    },
    image: '/assets/aistudio/image_d7646f21.png',
    gallery: [
      '/assets/aistudio/image_d7646f21.png'
    ],
    description: 'Conjunto completo com 25 enfeites tridimensionais em formato de flocos de neve para árvore de Natal, guirlandas e decoração festiva. Cada peça possui um recorte geométrico rendado único com orifício superior para passagem de fios ou ganchos. Leves, resistentes e reutilizáveis por muitos anos sem quebrar.',
    features: [
      'Preço do kit completo: R$ 60,00 (apenas R$ 2,40 por floco!)',
      'Contém 25 modelos geométricos distintos de flocos de neve rendados',
      'Leves e seguros: não quebram ao cair no chão e não envergam galhos',
      'Orifício superior de 3 mm integrado para fios de nylon, fitas de cetim ou ganchos',
      'Design elegante com acabamento texturizado de alta resolução',
      'Ideal para árvores de Natal, lareiras, vitrines e embalagens de presentes'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    isNew: true,
    bestSeller: true,
    availableColors: [
      { name: 'Branco Neve Clássico', hex: '#f8fafc' },
      { name: 'Dourado Silk Festivo', hex: '#d97706' },
      { name: 'Prata Silk Glacial', hex: '#94a3b8' },
      { name: 'Vermelho Natalino', hex: '#dc2626' }
    ],
    options: {
      name: 'Quantidade do Kit',
      choices: [
        { label: 'Kit Completo com 25 Flocos de Neve (R$ 60,00)', price: 60.00 },
        { label: 'Kit Compacto com 12 Flocos de Neve', price: 35.00 },
        { label: 'Combo 2 Kits (50 Flocos de Neve)', price: 110.00 }
      ]
    }
  },
  {
    id: 'figure-pokemon-umbreon-colecionavel-3d',
    name: 'Action Figure Pokémon Umbreon Colecionável 3D',
    category: 'anime',
    price: 42.00,
    originalPrice: 52.00,
    image: '/assets/aistudio/image_55f20cf2.png',
    gallery: [
      '/assets/aistudio/image_55f20cf2.png'
    ],
    description: 'Action figure escultural de alta fidelidade do Pokémon Umbreon (evolução tipo Noturno do Eevee). Apresenta acabamento preto acetinado com detalhes minuciosos em relevo nos anéis amarelos característicos das orelhas, testa e patas, além dos expressivos olhos vermelhos modelados com acabamento premium.',
    features: [
      'Modelagem exclusiva e acabamento de alta definição',
      'Anéis amarelos luminosos e olhos vermelhos contrastantes fiéis ao anime',
      'Pose sentada fofa e estável para mesas, estantes e setup gamer',
      'Item indispensável para colecionadores e fãs do universo Pokémon'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    isNew: true,
    bestSeller: true,
    options: {
      name: 'Versão do Umbreon',
      choices: [
        { label: 'Umbreon Tradicional (Anéis Amarelos / Olhos Vermelhos)', price: 42.00 },
        { label: 'Umbreon Shiny (Anéis Azul Celeste / Olhos Amarelos)', price: 45.00 }
      ]
    }
  },
  {
    id: 'kit-5-imas-pokebola',
    name: 'Kit 5 Ímãs de Geladeira Pokebola 3D',
    category: 'kits',
    price: 25.00,
    originalPrice: 32.00,
    bulkPrice: {
      minQuantity: 2,
      price: 22.00
    },
    image: '/assets/aistudio/image_faec46b9.png',
    gallery: [
      '/assets/aistudio/image_faec46b9.png'
    ],
    description: 'Conjunto com 5 ímãs decorativos de Pokebola em impressão 3D multicamadas com cores vivas e acabamento brilhante. Cada peça acompanha potente ímã de neodímio embutido na parte traseira, ideal para prender bilhetes, fotos, recados e decorar a geladeira, armários de aço ou gabinetes.',
    features: [
      'Conjunto completo com 5 ímãs Pokebola',
      'Ímã de neodímio de alta fixação embutido (não risca as superfícies)',
      'Impressão 3D de alta precisão com relevo do botão central',
      'Perfeito para geladeira, quadro magnético, setup gamer e presentear',
      'Preço promocional do kit: R$ 25,00 (sai por R$ 5,00 cada peça!)'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true,
    options: {
      name: 'Composição do Kit',
      choices: [
        { label: 'Kit 5 Pokebolas Tradicionais Clássicas', price: 25.00 },
        { label: 'Kit 5 Pokebolas Mistas (Tradicional, Great, Ultra, Master, Safari)', price: 28.00 },
        { label: '1x Ímã Pokebola Avulso', price: 6.00 },
        { label: 'Combo 2 Kits (10 Ímãs Pokebola)', price: 44.00 }
      ]
    }
  },
  {
    id: 'figure-charmander-flamethrower-3d',
    name: 'Action Figure Charmander Lança-Chamas 3D',
    category: 'anime',
    price: 42.00,
    originalPrice: 52.00,
    image: '/assets/aistudio/image_16d67227.png',
    gallery: [
      '/assets/aistudio/image_16d67227.png'
    ],
    description: 'Action figure colecionável de alta fidelidade do Charmander disparando sua clássica rajada de fogo (Lança-Chamas). A labareda e a chama da cauda possuem efeito esculpido tridimensional dinâmico, criando um visual impressionante para estantes e mesas de setup.',
    features: [
      'Modelagem detalhada com efeito de fogo realista em degradê amarelo e vermelho',
      'Olhos vívidos com reflexo e dentes modelados em relevo',
      'Base estável com apoio na ponta da labareda e nos pés',
      'Peça colecionável indispensável para fãs de Pokémon'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true
  },
  {
    id: 'incensario-gatinho-3d',
    name: 'Incensário Gatinho com Bandeja Coletora 3D',
    category: 'decoracao',
    price: 38.00,
    originalPrice: 48.00,
    image: '/assets/aistudio/image_fe317696.png',
    gallery: [
      '/assets/aistudio/image_fe317696.png'
    ],
    description: 'Incensário escultural em formato de gatinho esticado preguiçoso com orifício na ponta do rabinho para fixar a vareta de incenso. Acompanha bandeja oval com laterais caneladas que recolhe com perfeição todas as cinzas sem sujar o móvel.',
    features: [
      'Preço: R$ 38,00',
      'Rabo com encaixe seguro para varetas de incenso de qualquer aroma',
      'Bandeja oval canelada coletora de cinzas de 24 cm inclusa',
      'Design minimalista moderno em acabamento preto fosco acetinado',
      'Perfeito para amantes de gatos, cantinho zen, quartos e salas'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true,
    availableColors: [
      { name: 'Preto Fosco Texturizado', hex: '#0f172a' },
      { name: 'Branco Pérola Mármore', hex: '#f8fafc' },
      { name: 'Cinza Concreto Moderno', hex: '#64748b' },
      { name: 'Terracota Argila', hex: '#c2410c' }
    ]
  },
  {
    id: 'chaveiro-cruz-espirito-santo-3d',
    name: 'Chaveiro Cruz com Espírito Santo 3D',
    category: 'religioso',
    price: 15.00,
    originalPrice: 19.90,
    bulkPrice: {
      minQuantity: 3,
      price: 12.00
    },
    image: '/assets/aistudio/Captura_de_tela_2026-10-20_171224_d079b6cd.png',
    gallery: [
      '/assets/aistudio/Captura_de_tela_2026-10-20_171224_d079b6cd.png'
    ],
    description: 'Chaveiro de cruz sacra vazada com recorte geométrico e silhueta central da Pomba da Paz / Espírito Santo em revoada. Acompanha corrente metálica e argola italiana reforçada para chaves ou bolsas.',
    features: [
      'Preço unitário: R$ 15,00',
      'Desconto progressivo para lembranças: R$ 12,00 a partir de 3 unidades',
      'Argola e corrente metálicas reforçadas inclusas',
      'Ideal para lembrancinhas de crisma, batizado, catequese e retiro espiritual',
      'Material leve, resistente e lavável'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true,
    availableColors: [
      { name: 'Branco Neve Sagrado', hex: '#ffffff' },
      { name: 'Dourado Silk Nobre', hex: '#ca8a04' },
      { name: 'Prata Metálico Silk', hex: '#94a3b8' },
      { name: 'Preto Grafite Clássico', hex: '#1e293b' }
    ]
  },
  {
    id: 'kit-vasinhos-bonequinhos-suculentas-3d',
    name: 'Kit 4 Vasinhos Bonequinhos com Perninhas para Suculentas 3D',
    category: 'kits',
    price: 60.00,
    originalPrice: 79.90,
    image: '/assets/aistudio/WhatsApp_Image_2026-10-22_at_13.51.46_a990c022.jpeg',
    gallery: [
      '/assets/aistudio/WhatsApp_Image_2026-10-22_at_13.51.46_a990c022.jpeg'
    ],
    description: 'Coleção completa com 4 vasinhos / cachepots bonequinhos sentados com perninhas e poses expressivas super fofas: Sorriso gargalhada, Fazendo coração com as mãos, Segurando buquê de tulipas e Pose de força musculoso. Ideais para mini suculentas, cactos e plantas pendentes.',
    features: [
      'Kit completo com as 4 poses por R$ 60,00 (apenas R$ 15,00 cada vasinho!)',
      '4 poses colecionáveis exclusivas: Gargalhada, Coração, Buquê de Flores e Musculoso',
      'Apoiam firmemente na borda de prateleiras, mesas de centro, estantes e nichos',
      'Furo de drenagem opcional para plantio direto ou uso como cachepot',
      'Acabamento cerâmico acetinado de alta resolução'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true,
    availableColors: [
      { name: 'Branco Cerâmica Clássico', hex: '#ffffff' },
      { name: 'Preto Grafite Minimalista', hex: '#1e293b' },
      { name: 'Terracota Pastel', hex: '#ea580c' },
      { name: 'Verde Sálvia Suave', hex: '#84cc16' }
    ],
    options: {
      name: 'Opção de Compra',
      choices: [
        { label: 'Kit Completo 4 Vasinhos (Todas as Poses)', price: 60.00 },
        { label: '1x Vasinho Sorriso Gargalhada', price: 18.00 },
        { label: '1x Vasinho Coração com as Mãos', price: 18.00 },
        { label: '1x Vasinho Buquê de Tulipas', price: 18.00 },
        { label: '1x Vasinho Pose de Força Musculoso', price: 18.00 },
        { label: 'Combo 2 Kits (8 Vasinhos)', price: 110.00 }
      ]
    }
  },
  {
    id: 'kit-marcadores-de-biblia-3d',
    name: 'Kit 4 Marcadores de Página de Bíblia e Livros 3D',
    category: 'religioso',
    price: 20.00,
    originalPrice: 28.00,
    bulkPrice: {
      minQuantity: 2,
      price: 18.00
    },
    image: '/assets/aistudio/image_9d580f84.png',
    gallery: [
      '/assets/aistudio/image_9d580f84.png'
    ],
    description: 'Conjunto com 4 marcadores de página estilo clipe para bíblia, devocionais, catequese e livros. Conta com símbolos sagrados em alto relevo: Nossa Senhora Aparecida, ECC (Encontro de Casais com Cristo), Espírito Santo Radiante e Sagrada Família. Não amassa e nem danifica as folhas finas da Bíblia.',
    features: [
      'Preço do conjunto: R$ 20,00 (4 unidades)',
      'Desconto progressivo: R$ 18,00 cada kit comprando 2 ou mais',
      'Design estilo clipe que prende com suavidade e firmeza',
      'Símbolos: Nossa Senhora Aparecida, ECC, Espírito Santo e Sagrada Família',
      'Lembrança perfeita para batizados, crisma, primeira comunhão, encontros de casais e catequese'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true,
    availableColors: [
      { name: 'Branco Pérola Litúrgico', hex: '#f8fafc' },
      { name: 'Dourado Silk Nobre', hex: '#ca8a04' },
      { name: 'Madeira / Cobre Acetinado', hex: '#b45309' },
      { name: 'Preto Grafite Clássico', hex: '#1e293b' }
    ],
    options: {
      name: 'Selecione o Modelo ou Kit',
      choices: [
        { label: 'Kit Completo (4 Marcadores)', price: 20.00 },
        { label: '1x Marcador Nossa Senhora Aparecida', price: 6.00 },
        { label: '1x Marcador Espírito Santo Radiante', price: 6.00 },
        { label: '1x Marcador ECC Encontro de Casais', price: 6.00 },
        { label: '1x Marcador Sagrada Família', price: 6.00 },
        { label: 'Combo 2 Kits (8 Marcadores no total)', price: 36.00 }
      ]
    }
  },
  {
    id: 'incensario-flor-de-lotus-3d',
    name: 'Incensário Flor de Lótus - Suporte Para Incenso 3D',
    category: 'decoracao',
    price: 25.00,
    originalPrice: 35.00,
    image: '/assets/products/incensario-flor-de-lotus.png',
    gallery: [
      '/assets/products/incensario-flor-de-lotus.png'
    ],
    description: 'Incensário decorativo em formato de flor de lótus aberta esculpida em impressão 3D de alta definição. Conta com múltiplos orifícios no miolo para queima de incensos em vareta e base para incenso tipo cone, proporcionando harmonia, relaxamento e aromaterapia ao ambiente.',
    features: [
      'Preço promocional: R$ 25,00',
      'Compatível com incensos tradicionais em vareta e incenso tipo cone',
      'Pétalas florais concêntricas em camadas com acabamento escultural',
      'Fácil retenção e limpeza das cinzas com base estável',
      'Perfeito para cantinho zen, meditação, oratórios, mesas e aparadores'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true,
    availableColors: [
      { name: 'Preto Ônix Brilhante', hex: '#0f172a' },
      { name: 'Branco Pérola Acetinado', hex: '#f8fafc' },
      { name: 'Dourado Silk Nobre', hex: '#ca8a04' },
      { name: 'Verde Jade Suave', hex: '#059669' }
    ]
  },
  {
    id: 'chaveiro-sharingan-naruto',
    name: 'Chaveiro Sharingan / Mangekyou Uchiha 3D',
    category: 'anime',
    price: 15.00,
    originalPrice: 19.90,
    image: '/assets/aistudio/image_da7ca786.png',
    gallery: [
      '/assets/aistudio/image_da7ca786.png'
    ],
    description: 'Chaveiro temático dos olhos Sharingan e Mangekyou do clã Uchiha em impressão 3D de três cores (vermelho carmim, preto e branco). Acompanha argola metálica reforçada e corrente para chaves ou mochila.',
    features: [
      'Preço unitário: R$ 15,00',
      'Argola e corrente metálicas inclusas prontas para uso',
      'Impressão multicamadas com acabamento em relevo tátil',
      'Ultra resistente a quedas e uso diário'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true,
    options: {
      name: 'Selecione o Modelo de Sharingan',
      choices: [
        { label: 'Mangekyou Sasuke', price: 15.00 },
        { label: 'Mangekyou Itachi', price: 15.00 },
        { label: 'Mangekyou Kakashi / Obito', price: 15.00 },
        { label: 'Mangekyou Madara', price: 15.00 },
        { label: 'Sharingan Clássico 3 Tomoe', price: 15.00 },
        { label: 'Combo 3 Chaveiros à Escolha', price: 39.90 },
      ]
    }
  },
  {
    id: 'figure-hatsune-miku-chibi',
    name: 'Action Figure Chibi Hatsune Miku 3D',
    category: 'anime',
    price: 39.90,
    originalPrice: 49.90,
    image: '/assets/aistudio/image_c0f07592.png',
    gallery: [
      '/assets/aistudio/image_c0f07592.png'
    ],
    description: 'Miniatura colecionável estilo chibi da icônica Hatsune Miku (Vocaloid). Detalhes esculturais fiéis: marias-chiquinhas turquesas volumosas, fone de ouvido futurista, gravata ciano e base circular de suporte.',
    features: [
      'Modelagem 3D chibi de alta definição',
      'Cores originais e acabamento acetinado de estúdio',
      'Acompanha base circular de apoio para mesa e estantes',
      'Item indispensável para colecionadores e fãs de anime'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true
  },
  {
    id: 'placa-anime-eyes-shonen',
    name: 'Quadro de Mesa Anime Eyes Shonen Heroes 3D',
    category: 'anime',
    price: 48.00,
    originalPrice: 59.90,
    image: '/assets/aistudio/image_b595568c.png',
    gallery: [
      '/assets/aistudio/image_b595568c.png'
    ],
    description: 'Painel decorativo em relevo 3D preto e branco com o olhar marcante dos maiores protagonistas dos mangás: Goku (Dragon Ball), Naruto, Saitama (One Punch Man), Luffy (One Piece) e All Might (My Hero Academia).',
    features: [
      'Estilo painel de mangá com alto relevo contrastante',
      'Base estável para usar em mesas, aparadores e setup gamer',
      'Acabamento suave em duas tonalidades preto e branco',
      'Presente perfeito para amantes da cultura pop japonesa'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true
  },
  {
    id: 'placa-satoru-gojo-jujutsu',
    name: 'Placa Silhueta Satoru Gojo - Jujutsu Kaisen 3D',
    category: 'anime',
    price: 32.00,
    originalPrice: 39.90,
    image: '/assets/aistudio/image_a5e0dc44.png',
    gallery: [
      '/assets/aistudio/image_a5e0dc44.png'
    ],
    description: 'Placa decorativa vazada e em relevo do feiticeiro mais poderoso, Satoru Gojo de Jujutsu Kaisen, fazendo o icônico sinal de paz com as mãos e venda nos olhos.',
    features: [
      'Geometria precisa recortada em linhas marcantes',
      'Pode ser apoiada na mesa ou fixada na parede',
      'Material leve e super resistente',
      'Design minimalista moderno em preto e branco'
    ],
    material: 'PLA Premium',
    inStock: true
  },
  {
    id: 'kit-9-mandalas-natal-brancas',
    name: 'Kit 9 Enfeites de Natal Mandalas Vazadas Silhueta',
    category: 'natal',
    price: 25.00,
    originalPrice: 35.00,
    image: '/assets/aistudio/image_c0bc2387.png',
    gallery: [
      '/assets/aistudio/image_c0bc2387.png'
    ],
    description: 'Conjunto completo com 9 enfeites circulares vazados com belas silhuetas natalinas: Presépio na manjedoura, Anjo da Paz com coração, Árvores com presentes, Renas, Chalé de inverno e Trenó do Papai Noel.',
    features: [
      'Conjunto completo com 9 enfeites para árvore de Natal',
      'Acabamento em Branco Neve acetinado de alta resolução',
      'Orifício superior reforçado para passar fitas ou ganchos',
      'Design vazado elegante que destaca os pontos de iluminação da árvore'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true,
    availableColors: [
      { name: 'Branco Neve Clássico', hex: '#ffffff' },
      { name: 'Dourado Silk Nobre', hex: '#ca8a04' },
      { name: 'Vermelho Festivo', hex: '#dc2626' }
    ]
  },
  {
    id: 'kit-enfeites-arvore-linhas',
    name: 'Kit Enfeites de Árvore em Linhas Minimalistas',
    category: 'natal',
    price: 25.00,
    originalPrice: 32.00,
    image: '/assets/aistudio/image_cb418eb8.png',
    gallery: [
      '/assets/aistudio/image_cb418eb8.png'
    ],
    description: 'Conjunto de pingentes de árvore de Natal com silhuetas vazadas em linhas contínuas geométricas. Inclui pinheiros estilizados, velas com azevinho, flocos de neve rendados, bolas com coração, botas e Papai Noel.',
    features: [
      'Design em linhas contínuas moderno e elegante',
      'Cores vivas: Vermelho Noel, Verde Pinheiro, Amarelo Ouro e Branco Neve',
      'Extremamente leves para não envergar galhos finos da árvore',
      'Orifício superior reforçado para passar fitas ou ganchos'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true,
    options: {
      name: 'Escolha o Kit',
      choices: [
        { label: 'Kit 6 Peças Sortidas', price: 25.00 },
        { label: 'Kit 12 Peças Coleção Completa', price: 45.00 }
      ]
    },
    availableColors: [
      { name: 'Mix Festivo (Vermelho, Verde, Amarelo, Branco)', hex: '#dc2626' },
      { name: 'Mono Dourado Silk', hex: '#ca8a04' },
      { name: 'Branco Neve Escandinavo', hex: '#ffffff' }
    ]
  },
  {
    id: 'papai-noel-trico-3d',
    name: 'Papai Noel Estilo Tricô 3D (Amigurumi)',
    category: 'natal',
    price: 20.00,
    bulkPrice: {
      minQuantity: 2,
      price: 18.00
    },
    image: '/assets/aistudio/image_c6b79aa7.png',
    gallery: [
      '/assets/aistudio/image_c6b79aa7.png',
      '/assets/aistudio/IMG_1732_6c0018f4.jpeg'
    ],
    description: 'Papai Noel colecionável impresso em 3D com textura hiper-realista que reproduz os pontos manuais de crochê e tricô (amigurumi). Uma fofura natalina única para decorar aparadores, mesas e lareiras.',
    features: [
      'Textura tátil de tricô amigurumi hiper-realista',
      'Desconto progressivo: R$ 18,00 cada levando 2 ou mais peças',
      'Cores vibrantes: gorro e roupinha vermelha, barba branca e botas pretas',
      'Combina perfeitamente com a nossa Bandeja Canelada 3D'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true,
    options: {
      name: 'Selecione a Opção',
      choices: [
        { label: 'Somente o Papai Noel de Tricô', price: 20.00 },
        { label: 'Papai Noel + Bandeja Canelada 3D (Combo)', price: 45.00 },
      ]
    }
  },

  {
    id: 'kit-3-renas',
    name: 'Kit 3 Renas Minimalistas Esculturais',
    category: 'natal',
    price: 37.90,
    image: '/assets/aistudio/IMG_1731_67fdb6a8.jpeg',
    gallery: [
      '/assets/aistudio/IMG_1731_67fdb6a8.jpeg',
    ],
    description: 'Trio escultural de renas natalinas com design canelado orgânico minimalista. Proporciona um visual sofisticado e moderno para aparadores, mesas de centro ou lareiras.',
    features: [
      'Trio completo com 3 cores harmônicas (Creme, Vermelho e Verde)',
      'Design canelado contemporâneo em curvas suaves',
      'Opção de combo promocional com bandeja canelada inclusa',
      'Impressão 3D densa com base estável'
    ],
    material: 'PLA Premium',
    inStock: true,
    isFeatured: true,
    bestSeller: true,
    options: {
      name: 'Escolha a Composição',
      choices: [
        { label: 'Kit 3 Renas (Sem Bandeja)', price: 37.90 },
        { label: 'Kit 3 Renas + Bandeja Canelada (Economize R$ 12)', price: 55.90 }
      ]
    }
  },

  {
    id: 'kit-completo-amigurumis-bandeja',
    name: 'Kit Completo Natal Encantado (6 Peças + Bandeja)',
    category: 'kits',
    price: 120.00,
    originalPrice: 150.00,
    image: '/assets/aistudio/IMG_1732_6c0018f4.jpeg',
    description: 'O combo mais desejado da temporada: leva os 6 personagens amigurumi 3D (Papai Noel, Boneco de Neve, Biscoitinho, Rena, Ursinho e Pinheirinho) junto com a bandeja canelada inclusa com R$ 30 de desconto!',
    features: [
      'Todos os 6 personagens natalinos reunidos',
      'Bandeja canelada de 18cm inclusa',
      'Economia de R$ 30 em relação aos itens separados',
      'Embalagem pronta para presente'
    ],
    material: 'PLA Premium',
    inStock: true,
    bestSeller: true,
    isFeatured: true
  },
  {
    id: 'kit-renas-bandeja-combo',
    name: 'Combo Trio de Renas + Bandeja Canelada',
    category: 'kits',
    price: 55.90,
    originalPrice: 67.90,
    image: '/assets/aistudio/IMG_1731_67fdb6a8.jpeg',
    description: 'Decoração completa pronta para mesa de jantar ou aparador de entrada. Trio de renas esculpidas em relevo acompanhadas da bandeja canelada em tom neutro.',
    features: [
      'Trio de renas nas cores Creme, Vermelho e Verde',
      'Bandeja canelada inclusa no combo',
      'Pronto para compor com luzes pisca-pisca ou pinhas',
      'Fácil de limpar e guardar para os próximos anos'
    ],
    material: 'PLA Premium',
    inStock: true,
    bestSeller: true
  },
  {
    id: 'grade-protetor-cooler-fan-120mm-aranha',
    name: "Grade Protetor de Cooler Fan 120mm Homem-Aranha 3D",
    category: 'geek',
    price: 12.00,
    originalPrice: 18.00,
    image: '/assets/products/grade-cooler-aranha-120mm.png',
    gallery: ["/assets/products/grade-cooler-aranha-120mm.png"],
    description: "Grade protetora decorativa personalizada para ventoinhas e coolers de 120mm de gabinetes PC Gamer. Possui padr\u00e3o de teia de aranha que deixa o fluxo de ar e a ilumina\u00e7\u00e3o RGB passarem livremente enquanto protege contra toques acidentais e enriquece o visual do setup.",
    features: ["Encaixe perfeito na fura\u00e7\u00e3o padr\u00e3o de 120mm para PC Gamer", "N\u00e3o obstrui o fluxo de ar nem gera ru\u00eddo excessivo", "Destaque incr\u00edvel com ventoinhas RGB acesas", "Instala\u00e7\u00e3o simples com os pr\u00f3prios parafusos do cooler"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true,
  },
  {
    id: 'kit-3-marcadores-de-livro-textura-cubo',
    name: "KIT 3 Marcadores de Livro com Textura Geom\u00e9trica 3D",
    category: 'utilidades',
    price: 12.90,
    originalPrice: 19.90,
    image: '/assets/products/kit-3-marcadores-cubo-3d.png',
    gallery: ["/assets/products/kit-3-marcadores-cubo-3d.png"],
    description: "Conjunto com 3 marcadores de p\u00e1gina estilo clipe fino com ponteira em relevo geom\u00e9trico 3D (cubo aramado/textura prism\u00e1tica). Fixa a p\u00e1gina do livro ou apostila sem deixar marcas nem rasgar o papel.",
    features: ["Kit completo com 3 unidades por R$ 12,90 (R$ 4,30 cada)", "Clipe longo e flex\u00edvel que n\u00e3o deforma a lombada", "Ponteira estilizada que fica aparente no topo do livro", "\u00d3tima op\u00e7\u00e3o para estudantes, leitores e devocionais"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
  },
  {
    id: 'kit-marcador-ns-aparecida-par-preto-branco',
    name: "Kit 10 Marcadores de Página Nossa Senhora Aparecida 3D",
    category: 'religioso',
    price: 20.00,
    originalPrice: 28.00,
    bulkPrice: {
      minQuantity: 2,
      price: 18.00
    },
    image: '/assets/products/marcador-ns-aparecida-par.png',
    gallery: ["/assets/products/marcador-ns-aparecida-par.png"],
    description: "Conjunto devocional com 10 marcadores de página com a silhueta em alto relevo de Nossa Senhora Aparecida com coroa e manto rendado com cruz sagrada. Preço promocional: R$ 20,00 o pacote com 10 unidades (sai a apenas R$ 2,00 cada!). Clipe suave e seguro para Bíblias e livros religiosos sem marcar nem rasgar as folhas.",
    features: [
      "Kit com 10 unidades por apenas R$ 20,00 (R$ 2,00 cada peça)",
      "Silhueta devocional com manto rendado e cruz sagrada em alto relevo",
      "Não amassa nem danifica as páginas delicadas da Bíblia",
      "Lembrancinha perfeita de fé para batizados, crisma, catequese e grupos de oração"
    ],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true,
    options: {
      name: 'Composição de Cores do Kit',
      choices: [
        { label: 'Kit 10 Marcadores Misto (5 Brancos + 5 Pretos) - R$ 20,00', price: 20.00 },
        { label: 'Kit 10 Marcadores Todos Brancos - R$ 20,00', price: 20.00 },
        { label: 'Kit 10 Marcadores Todos Pretos - R$ 20,00', price: 20.00 },
        { label: 'Combo 2 Kits (20 Marcadores) - R$ 36,00', price: 36.00 }
      ]
    }
  },
  {
    id: 'kit-3-pares-ganchos-antiderrapante-oculos',
    name: "Kit 3 Pares de Gancho Antiderrapante para \u00d3culos 3D",
    category: 'utilidades',
    price: 15.00,
    originalPrice: 22.00,
    image: '/assets/products/ganchos-hastes-oculos-3pares.png',
    gallery: ["/assets/products/ganchos-hastes-oculos-3pares.png"],
    description: "Kit com 3 pares (6 unidades) de suportes anat\u00f4micos para hastes de \u00f3culos de grau ou sol. Segura as hastes suavemente atr\u00e1s das orelhas, impedindo que os \u00f3culos escorreguem no nariz durante corrida, academia, transpira\u00e7\u00e3o ou trabalho.",
    features: ["Cont\u00e9m 3 pares completos no kit", "Design ergon\u00f4mico curvo invis\u00edvel atr\u00e1s da orelha", "Encaixe universal compat\u00edvel com a maioria das hastes", "Acabamento liso sem rebarbas para total conforto"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
  },
  {
    id: 'kit-3-ganchos-de-parede-multiuso-reforcados',
    name: "Kit 3 Ganchos de Parede Multiuso Refor\u00e7ados 3D",
    category: 'utilidades',
    price: 18.00,
    originalPrice: 26.00,
    image: '/assets/products/kit-3-ganchos-parede-multiuso.png',
    gallery: ["/assets/products/kit-3-ganchos-parede-multiuso.png"],
    description: "Conjunto com 3 ganchos angulares refor\u00e7ados para parede com fura\u00e7\u00e3o para parafusos ou uso com fita dupla-face extra forte. Perfeito para pendurar casacos, toalhas, mochilas, bon\u00e9s, ferramentas ou fones.",
    features: ["Kit com 3 ganchos com perfil em L e aba de seguran\u00e7a", "Fabricado em material refor\u00e7ado com alta capacidade de carga", "Acompanha fura\u00e7\u00e3o escareada para fixa\u00e7\u00e3o limpa", "Design moderno e discreto em preto fosco"],
    material: 'PETG Resistente',
    inStock: true,
    isNew: true,
  },
  {
    id: 'suporte-duplo-de-parede-multiuso-reforcado',
    name: "Suporte Duplo de Parede Multiuso Refor\u00e7ado 3D",
    category: 'utilidades',
    price: 20.00,
    originalPrice: 28.00,
    image: '/assets/products/suporte-duplo-parede-reforcado.png',
    gallery: ["/assets/products/suporte-duplo-parede-reforcado.png"],
    description: "Suporte modular de parede com bra\u00e7o duplo em perfil geom\u00e9trico de alta rigidez. Ideal para suportar fones de ouvido, cabos enrolados, ferramentas, skates, pranchas ou vassouras com firmeza e organiza\u00e7\u00e3o na garagem ou escrit\u00f3rio.",
    features: ["Dois pontos de apoio paralelos com reten\u00e7\u00e3o nas pontas", "Refor\u00e7o interno para sustenta\u00e7\u00e3o de peso sem envergar", "Design industrial limpo e funcional", "F\u00e1cil de parafusar em alvenaria ou madeira"],
    material: 'PETG Resistente',
    inStock: true,
    isNew: true,
  },
  {
    id: 'suporte-controle-mascara-samurai-oni',
    name: "Suporte Controle PS5 PS4 Xbox M\u00e1scara Samurai Oni 3D",
    category: 'geek',
    price: 20.00,
    originalPrice: 32.00,
    image: '/assets/products/suporte-controle-mascara-oni.png',
    gallery: ["/assets/products/suporte-controle-mascara-oni.png"],
    description: "Suporte tem\u00e1tico para controles de videogame com a escultura da m\u00edstica m\u00e1scara Samurai Oni/Hannya. O controle (PS5 DualSense, PS4, Xbox Series ou Nintendo Switch) se encaixa perfeitamente no topo completando a m\u00e1scara como se fossem os olhos do guerreiro!",
    features: ["Pre\u00e7o promocional de lan\u00e7amento: R$ 20,00", "Encaixe anat\u00f4mico est\u00e1vel para controles de todas as marcas", "Detalhes ricos dos dentes, presas e relevo facial", "Base ampla com apoio est\u00e1vel para mesa gamer"],
    material: 'PETG Resistente',
    inStock: true,
    isNew: true,
    bestSeller: true,
  },
  {
    id: 'kit-2-chaveiros-abridor-latas-monster',
    name: "Kit 2 Chaveiros Abridor de Latas Monster Energy 3D",
    category: 'geek',
    price: 20.00,
    originalPrice: 28.00,
    image: '/assets/products/chaveiro-abridor-monster-par.png',
    gallery: ["/assets/products/chaveiro-abridor-monster-par.png"],
    description: "Par de chaveiros refor\u00e7ados em duas cores com a cl\u00e1ssica garra verde Monster Energy sobre fundo texturizado preto. Possui encaixe especial na ponta que auxilia a abrir an\u00e9is de latas sem quebrar as unhas ou machucar os dedos.",
    features: ["Cont\u00e9m 2 chaveiros completos com argolas met\u00e1licas", "Garras em alto relevo verde fluorescente sobre preto texturizado", "Fun\u00e7\u00e3o pr\u00e1tica 2 em 1: chaveiro estiloso + abridor de latas", "Resistente a quedas e uso no bolso"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
  },
  {
    id: 'suporte-de-mesa-headset-fone-morsa',
    name: "Suporte de Mesa Headset com Morsa Borboleta 3D",
    category: 'geek',
    price: 20.00,
    originalPrice: 29.90,
    image: '/assets/products/suporte-mesa-headset-morsa.png',
    gallery: ["/assets/products/suporte-mesa-headset-morsa.png"],
    description: "Suporte com presilha tipo morsa rosque\u00e1vel para fixa\u00e7\u00e3o r\u00e1pida na lateral ou tampo de mesas, prateleiras ou balc\u00f5es sem necessidade de furos ou cola. Mant\u00e9m o fone de ouvido seguro e libera espa\u00e7o \u00fatil na sua bancada de trabalho.",
    features: ["Parafuso borboleta ajust\u00e1vel para diferentes espessuras de tampo", "Curvatura ergon\u00f4mica que preserva o arco e as espumas do headset", "Superf\u00edcie com textura antideslizante", "F\u00e1cil de remover ou reposicionar a qualquer momento"],
    material: 'PETG Resistente',
    inStock: true,
    isNew: true,
  },
  {
    id: 'crucifixo-vazado-face-cristo-design-elegante',
    name: "Crucifixo Vazado com Face de Cristo \u2013 Design Sacro 3D",
    category: 'religioso',
    price: 20.00,
    originalPrice: 28.00,
    image: '/assets/products/crucifixo-face-cristo.png',
    gallery: ["/assets/products/crucifixo-face-cristo.png"],
    description: "Cruz sacra estilizada com desenho geom\u00e9trico e vazado milim\u00e9trico que forma o semblante compassivo de Jesus Cristo com a coroa de espinhos. Pode ser utilizada sobre a mesa ou fixada na parede do orat\u00f3rio e sala.",
    features: ["Design elegante que une tradi\u00e7\u00e3o e modernidade lit\u00fargica", "Efeito de sombra tridimensional projetado na parede", "Pre\u00e7o acess\u00edvel: R$ 20,00", "Material ecol\u00f3gico, dur\u00e1vel e f\u00e1cil de limpar"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true,
  },
  {
    id: 'miniatura-trono-de-ferro-game-of-thrones',
    name: "Miniatura Trono de Ferro Game of Thrones 3D",
    category: 'geek',
    price: 20.00,
    originalPrice: 30.00,
    image: '/assets/products/trono-de-ferro-got.png',
    gallery: ["/assets/products/trono-de-ferro-got.png"],
    description: "R\u00e9plica escultural do ic\u00f4nico Trono de Ferro de Westeros (Game of Thrones / House of the Dragon), forjado com centenas de espadas fundidas em relevo 3D n\u00edtido e acabamento em preto grafite forjado.",
    features: ["Dezenas de l\u00e2minas pontiagudas esculpidas nos bra\u00e7os e encosto", "Base circular s\u00f3lida e est\u00e1vel para escrivaninhas e estantes", "Item colecion\u00e1vel obrigat\u00f3rio para f\u00e3s de fantasia medieval", "Pre\u00e7o imbat\u00edvel: R$ 20,00"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true,
  },
  {
    id: 'vasinho-planta-gato-preto-decorativo',
    name: "Vasinho de Planta Gato Preto Decorativo 3D",
    category: 'decoracao',
    price: 20.00,
    originalPrice: 28.00,
    image: '/assets/products/vasinho-gato-preto-suculenta.png',
    gallery: ["/assets/products/vasinho-gato-preto-suculenta.png"],
    description: "Charmoso cachepot em formato de gatinho preto sentado de olhos fechados sereno. A abertura superior \u00e9 perfeita para cultivar mini suculentas, cactos ou colocar raminhos de lavanda e flores arom\u00e1ticas.",
    features: ["Acabamento acetinado fosco com formas org\u00e2nicas suaves", "Furo para arranjos ou vasinho de plantas naturais", "Combina com qualquer c\u00f4modo da casa ou escrit\u00f3rio", "Pre\u00e7o de cat\u00e1logo: R$ 20,00"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
  },
  {
    id: 'kit-3-suporte-porta-oculos-quebra-sol-carro',
    name: "Kit 3 Suportes Porta-\u00d3culos Para Quebra-Sol de Carro 3D",
    category: 'utilidades',
    price: 25.00,
    originalPrice: 35.00,
    image: '/assets/products/suporte-oculos-quebra-sol.png',
    gallery: ["/assets/products/suporte-oculos-quebra-sol.png"],
    description: "Kit com 3 suportes Aero-Clip que se acoplam firmemente na aba do quebra-sol de qualquer autom\u00f3vel. Permitem prender e retirar seus \u00f3culos de sol com uma s\u00f3 m\u00e3o sem soltar a dire\u00e7\u00e3o, sem amassar as hastes e sem riscar o estofado do carro.",
    features: ["Cont\u00e9m 3 suportes completos para o motorista e passageiros", "Fixa\u00e7\u00e3o por mola de press\u00e3o de alta durabilidade", "Abertura r\u00e1pida com uma \u00fanica m\u00e3o", "Design aerodin\u00e2mico discreto em fibra de carbono fosca"],
    material: 'PETG Resistente',
    inStock: true,
    isNew: true,
  },
  {
    id: 'suporte-celular-dragao-furia-da-noite',
    name: "Suporte de Mesa para Celular Drag\u00e3o F\u00faria da Noite 3D",
    category: 'geek',
    price: 26.00,
    originalPrice: 36.00,
    image: '/assets/products/suporte-celular-dragao-banguela.png',
    gallery: ["/assets/products/suporte-celular-dragao-banguela.png"],
    description: "Suporte de celular super carism\u00e1tico esculpido como o drag\u00e3o Banguela (Como Treinar o Seu Drag\u00e3o). Com as asas abertas e patinhas dianteiras, ele apoia seu celular com total estabilidade na horizontal para ver s\u00e9ries e v\u00eddeos ou na vertical para chamadas.",
    features: ["Apoio seguro para smartphones de todos os tamanhos e capas", "\u00c2ngulo de vis\u00e3o ideal para assistir v\u00eddeos, aulas e reuni\u00f5es", "Escultura rica em relevos de escamas e asas de drag\u00e3o", "Destaque lindo na mesa de estudos e setup gamer"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true,
  },
  {
    id: 'kit-3-protetor-cabo-usbc-anti-quebra',
    name: "Kit 3 Protetores de Cabo USB-C Anti-Quebra 3D",
    category: 'utilidades',
    price: 28.00,
    originalPrice: 38.00,
    image: '/assets/products/protetor-cabo-usbc-kit3.png',
    gallery: ["/assets/products/protetor-cabo-usbc-kit3.png"],
    description: "Conjunto com 3 protetores anat\u00f4micos para cabos de carregador USB-C e Lightning. O design com haste sanfonada texturizada distribui a tens\u00e3o do cabo quando dobrado, evitando o desgaste precoce, fios partidos e mau contato.",
    features: ["Trio com 3 protetores em tons modernos (Preto e Branco)", "Encaixe firme que n\u00e3o desliza pelo fio", "Prolonga a vida \u00fatil de cabos caros de celulares e tablets", "Instala\u00e7\u00e3o r\u00e1pida por encaixe lateral tipo snap-on"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
  },
  {
    id: 'kit-18-miniaturas-dinossauros-repteis',
    name: "Kit 18 Miniaturas de Dinossauros e R\u00e9pteis 3D",
    category: 'geek',
    price: 29.00,
    originalPrice: 39.00,
    image: '/assets/products/dinossauros-18-pecas.png',
    gallery: ["/assets/products/dinossauros-18-pecas.png"],
    description: "Cole\u00e7\u00e3o completa com 18 miniaturas detalhadas de dinossauros e r\u00e9pteis pr\u00e9-hist\u00f3ricos em impress\u00e3o 3D (T-Rex, Tricer\u00e1tops, Pterod\u00e1ctilo, Braquiossauro, Espinossauro e muito mais). Pe\u00e7as leves, com alto n\u00edvel de detalhes e acabamento acetinado para brincar, colecionar, maquetes escolares ou decorar o quarto infantil.",
    features: ["18 miniaturas exclusivas de dinossauros no mesmo kit", "Custa apenas R$ 1,61 por miniatura", "Material at\u00f3xico, seguro e lav\u00e1vel", "Excelente para lembrancinhas, dioramas e colecionadores"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true,
  },
  {
    id: 'suporte-papel-higienico-ovelhinha-3d',
    name: "Suporte Para Papel Higi\u00eanico Ovelha Divertida 3D",
    category: 'decoracao',
    price: 30.00,
    originalPrice: 39.90,
    image: '/assets/products/suporte-papel-ovelhinha.png',
    gallery: ["/assets/products/suporte-papel-ovelhinha.png"],
    description: "Suporte decorativo e divertido para banheiro composto por cabecinha expressiva com orelhinhas e quatro patinhas de ovelha. Ao colocar um rolo de papel higi\u00eanico convencional no suporte, ele se transforma no corpinho fofinho da ovelha!",
    features: ["Design criativo e bem-humorado que encanta visitas", "As 4 patinhas apoiam firmemente na bancada ou sobre a caixa acoplada", "Compat\u00edvel com qualquer rolo de papel higi\u00eanico tradicional", "Material resistente \u00e0 umidade do banheiro e f\u00e1cil de lavar"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true,
  },
  {
    id: 'kit-5-chaveiros-espirito-santo-bastidor',
    name: "Kit 5 Chaveiros Divino Esp\u00edrito Santo Bastidor 3D",
    category: 'religioso',
    price: 30.00,
    originalPrice: 45.00,
    image: '/assets/products/chaveiro-espirito-santo-bastidor-5un.png',
    gallery: ["/assets/products/chaveiro-espirito-santo-bastidor-5un.png"],
    description: "Conjunto com 5 chaveiros/pingentes redondos inspirados na arte sacra de bastidor. Possuem moldura circular, feixe de raios dourados e a pomba da paz em alto relevo branco. Ideal para lembrancinhas de batizado, crisma, primeira comunh\u00e3o e casamentos.",
    features: ["Kit promocional com 5 unidades por R$ 30,00 (apenas R$ 6,00 cada)", "Acompanha corrente e argola dourada", "Dupla cor com raios detalhados e pomba central", "Embalados com zelo para lembran\u00e7as e presentes religiosos"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
  },
  {
    id: 'miniatura-arca-da-alianca-petg-dourado',
    name: "Arca da Aliança Bíblica 3D (PETG)",
    category: 'religioso',
    price: 32.00,
    originalPrice: 45.00,
    image: '/assets/products/miniatura-arca-da-alianca.png',
    gallery: ["/assets/products/miniatura-arca-da-alianca.png"],
    description: "R\u00e9plica escultural detalhada da Arca da Alian\u00e7a sagrada descrita no livro de \u00caxodo. Inclui a tampa do Propiciat\u00f3rio com os dois Querubins esculpidos de asas estendidas, relevos decorativos nas paredes e var\u00f5es laterais de transporte.",
    features: ["Fabricada em PETG de alta tenacidade e acabamento dourado silk", "Detalhes minuciosos dos Querubins e das argolas sagradas", "Pe\u00e7a expressiva para escolas dominicais, orat\u00f3rios e pastores", "Pre\u00e7o promocional: R$ 32,00"],
    material: 'PETG Resistente',
    inStock: true,
    isNew: true,
  },
  {
    id: 'kit-3-fantasmas-decorativos-halloween',
    name: "Kit 3 Bonecos Fantasma Decorativo Branco 3D",
    category: 'decoracao',
    price: 32.00,
    originalPrice: 42.00,
    image: '/assets/products/fantasmas-decorativos-kit3.png',
    gallery: ["/assets/products/fantasmas-decorativos-kit3.png"],
    description: "Trio de fantasminhas fofos em impress\u00e3o 3D fosca, imitando len\u00e7ol ondulado com olhinhos expressivos. Trazem um ar divertido e moderno de Halloween ou decora\u00e7\u00e3o descontra\u00edda para mesas, estantes e nichos.",
    features: ["Conjunto completo com 3 express\u00f5es/poses de fantasminha", "Apenas R$ 10,66 por pe\u00e7a no kit", "Acabamento branco fosco suave tipo cer\u00e2mica", "Base est\u00e1vel anti-queda"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
  },
  {
    id: 'prateleira-de-canto-banheiro-box-escorredor',
    name: "Prateleira de Canto para Banheiro Box com Escorredor 3D",
    category: 'utilidades',
    price: 34.00,
    originalPrice: 46.00,
    image: '/assets/products/prateleira-canto-banheiro.png',
    gallery: ["/assets/products/prateleira-canto-banheiro.png"],
    description: "Prateleira triangular de 90\u00b0 projetada para o canto do box de banheiro ou pia. Possui ranhuras conc\u00eantricas com \u00e2ngulo de inclina\u00e7\u00e3o que escoam toda a \u00e1gua rapidamente para o ralo, prevenindo o ac\u00famulo de sab\u00e3o e fungos sob shampoos e sabonetes.",
    features: ["Ranhuras autolimpantes de escoamento r\u00e1pido de \u00e1gua", "Fabricada em PETG com resist\u00eancia total \u00e0 \u00e1gua quente e sab\u00e3o", "Bordas arredondadas e abas de conten\u00e7\u00e3o anti-queda", "Instala\u00e7\u00e3o por parafusos ou adesivo de silicone de alta fixa\u00e7\u00e3o"],
    material: 'PETG Resistente',
    inStock: true,
    isNew: true,
  },
  {
    id: 'bowl-organizador-dachshund-salsicha',
    name: "Bowl Dachshund | Cachorro Salsicha Porta-Chaves 3D",
    category: 'utilidades',
    price: 35.00,
    originalPrice: 45.00,
    image: '/assets/products/bowl-dachshund-salsicha.png',
    gallery: ["/assets/products/bowl-dachshund-salsicha.png"],
    description: "Organizador escultural no formato do carism\u00e1tico c\u00e3ozinho Dachshund (salsichinha) com dorso c\u00f4ncavo alargado. Perfeito como porta-chaves no hall de entrada, organizador de moedas, fone de ouvido, an\u00e9is ou doces na mesa de centro e escrit\u00f3rio.",
    features: ["Design anat\u00f4mico com orelhinhas ca\u00eddas e rabo empinado", "Tigela interna espa\u00e7osa para chaves de casa e carro", "Op\u00e7\u00e3o de acabamento Preto Fosco, Caramelo ou Branco", "Excelente presente para pais e m\u00e3es de pets"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true,
    options: {"name": "Modelo do Dachshund", "choices": [{"label": "Bowl Dachshund Porta-Chaves Grande", "price": 35.0}, {"label": "Organizador de Mesa Dachshund Compacto", "price": 30.0}]},
  },
  {
    id: 'porta-terco-nossa-senhora-escultura-minimalista',
    name: "Porta Ter\u00e7o Nossa Senhora \u2013 Escultura Minimalista & Bandeja",
    category: 'religioso',
    price: 36.00,
    originalPrice: 46.00,
    image: '/assets/products/porta-terco-minimalista-36.png',
    gallery: ["/assets/products/porta-terco-minimalista-36.png"],
    description: "Escultura sacra elegante de Nossa Senhora em manto cont\u00ednuo minimalista integrada \u00e0 bandeja porta-ter\u00e7o, orat\u00f3rio e joias. Suas m\u00e3os postas em ora\u00e7\u00e3o e a concavidade frontal oferecem um repouso reverente para o ter\u00e7o sagrado no orat\u00f3rio ou criado-mudo.",
    features: ["Design fluido e minimalista contempor\u00e2neo", "Bandeja frontal c\u00f4ncava ideal para acomodar ter\u00e7os de qualquer tamanho", "Acabamento acetinado marfim / branco p\u00e9rola", "S\u00edmbolo de b\u00ean\u00e7\u00e3o e ora\u00e7\u00e3o no lar"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true,
  },
  {
    id: 'porta-lata-caneca-termica-monster-branca',
    name: "Caneca Porta-Lata Monster Energy 3D",
    category: 'geek',
    price: 40.00,
    originalPrice: 55.00,
    image: '/assets/products/caneca-porta-lata-monster.png',
    gallery: ["/assets/products/caneca-porta-lata-monster.png"],
    description: "Caneca t\u00e9rmica ergon\u00f4mica com al\u00e7a refor\u00e7ada e abertura interna calibrada para encaixar perfeitamente a lata grande de Monster Energy (473ml). O corpo espesso em impress\u00e3o 3D isola a temperatura, mantendo a bebida estupidamente gelada e sem molhar a m\u00e3o.",
    features: ["Compat\u00edvel com latas de 473ml (Monster, Red Bull grande, cervejas lat\u00e3o)", "Al\u00e7a anat\u00f4mica confort\u00e1vel para longas sess\u00f5es de gameplay", "Logo da garra Monster vazado com contraste elegante", "Fundo com orif\u00edcio de despressuriza\u00e7\u00e3o para sacar a lata facilmente"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
  },
  {
    id: 'porta-terco-nossa-senhora-bandeja-oval',
    name: "Porta Ter\u00e7o Nossa Senhora com Bandeja Oval Canelada 3D",
    category: 'religioso',
    price: 40.00,
    originalPrice: 54.00,
    image: '/assets/products/porta-terco-nossa-senhora-bandeja-oval.png',
    gallery: ["/assets/products/porta-terco-nossa-senhora-bandeja-oval.png"],
    description: "Composi\u00e7\u00e3o de orat\u00f3rio com est\u00e1tua de Nossa Senhora em ora\u00e7\u00e3o posicionada sobre ampla bandeja oval canelada com relevo e frase sacra. Espa\u00e7o generoso para acolher ter\u00e7o de madeira, vela, chaves ou ora\u00e7\u00f5es do dia.",
    features: ["Bandeja oval ampla com laterais caneladas sofisticadas", "Est\u00e1tua central com manto detalhado e m\u00e3os postas", "Grava\u00e7\u00e3o suave em relevo no fundo da bandeja", "Visual nobre de m\u00e1rmore suave acetinado"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
  },
  {
    id: 'presepio-minimalista-sagrada-familia-estrela',
    name: "Pres\u00e9pio Minimalista da Sagrada Fam\u00edlia com Estrela de Bel\u00e9m",
    category: 'natal',
    price: 43.00,
    originalPrice: 55.00,
    image: '/assets/products/presepio-sagrada-familia-estrela.png',
    gallery: ["/assets/products/presepio-sagrada-familia-estrela.png"],
    description: "Pres\u00e9pio de Natal escultural com a Sagrada Fam\u00edlia (S\u00e3o Jos\u00e9, Maria e o Menino Jesus na manjedoura) sob arco protetor encimado pela radiante Estrela de Bel\u00e9m em 3D.",
    features: ["Estrela de Bel\u00e9m no topo do arco escultural", "Silhuetas puras que destacam a ilumina\u00e7\u00e3o natalina", "Pre\u00e7o especial: R$ 43,00", "Pe\u00e7a atemporal que celebra o verdadeiro esp\u00edrito do Natal"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true,
    options: {
      name: 'Estilo do Presépio',
      choices: [
        { label: 'Modelo Minimalista com Estrela (R$ 43,00)', price: 43.00 },
        { label: 'Modelo Estilo Tricot Completo (R$ 80,00)', price: 80.00 }
      ]
    },
  },
  {
    id: 'gato-preto-assustado-halloween-decorativo',
    name: "Gato Preto Assustado Arrepiado Halloween 3D",
    category: 'decoracao',
    price: 50.00,
    originalPrice: 68.00,
    image: '/assets/products/gato-preto-assustado-halloween.png',
    gallery: ["/assets/products/gato-preto-assustado-halloween.png"],
    description: "Escultura din\u00e2mica de um gato preto assustado com dorso arqueado, rabo eri\u00e7ado e pelos arrepiados modelados em 3D. Os olhos amarelos vibrantes com pupila de fenda criam um contraste magn\u00e9tico e misterioso para amantes de gatos e noites tem\u00e1ticas.",
    features: ["Textura tridimensional pontiaguda de pelos arrepiados", "Olhos amarelos expressivos de alto impacto visual", "Postura felina arqueada cheia de atitude e personalidade", "Pe\u00e7a de destaque em estantes, mesas e vitrines tem\u00e1ticas"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
  },
  {
    id: 'vaso-decorativo-preto-fantasma-halloween',
    name: "Vaso Decorativo Fantasma G\u00f3tico Halloween 3D",
    category: 'decoracao',
    price: 50.00,
    originalPrice: 68.00,
    image: '/assets/products/vaso-fantasma-preto-halloween.png',
    gallery: ["/assets/products/vaso-fantasma-preto-halloween.png"],
    description: "Vaso escultural g\u00f3tico em acabamento preto acetinado esculpido na silhueta de um fantasma sombrio com detalhes de ab\u00f3boras na base. Ideal para arranjos de flores secas, rosas escuras, lavanda ou como pe\u00e7a central m\u00edstica.",
    features: ["Design escultural misterioso e contempor\u00e2neo", "Base com mini ab\u00f3boras esculpidas em relevo", "Bocal amplo para acomodar buqu\u00eas de flores secas ou artificiais", "Acabamento premium preto fosco profundo"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
  },
  {
    id: 'suporte-parede-ciclista-completo',
    name: "Suporte de Parede Ciclista para Capacete, Sapatilhas, \u00d3culos e GPS 3D",
    category: 'utilidades',
    price: 55.00,
    originalPrice: 75.00,
    image: '/assets/products/suporte-parede-ciclista-completo.png',
    gallery: ["/assets/products/suporte-parede-ciclista-completo.png"],
    description: "O organizador definitivo de parede para ciclistas de MTB, Speed e Urbana. Estrutura monobloco refor\u00e7ada que acomoda tudo em um s\u00f3 lugar: apoio superior para ciclo-computador/GPS, ganchos laterais para par de sapatilhas de ciclismo, suporte de \u00f3culos esportivo e gancho inferior para capacete.",
    features: ["Suporta os 4 equipamentos principais do ciclista simultaneamente", "Fabricado em PETG de alta tenacidade estrutural", "Mant\u00e9m as sapatilhas arejadas para secagem p\u00f3s-treino", "Economiza espa\u00e7o e deixa o quarto ou garagem organizado com estilo"],
    material: 'PETG Resistente',
    inStock: true,
    isNew: true,
    bestSeller: true,
  },
  {
    id: 'suporte-headset-homem-aranha-cabeca-vazada',
    name: "Suporte de Headset Homem-Aranha Cabe\u00e7a Vazada 3D",
    category: 'geek',
    price: 55.00,
    originalPrice: 75.00,
    image: '/assets/products/suporte-headset-homem-aranha-vazado.png',
    gallery: ["/assets/products/suporte-headset-homem-aranha-vazado.png"],
    description: "Busto decorativo vazado de propor\u00e7\u00f5es ideais com a m\u00e1scara e olhos emblem\u00e1ticos do Homem-Aranha sobre base com a ins\u00edgnia Spider. O arco superior suporta qualquer modelo de headset gamer confortavelmente sem pressionar as almofadas.",
    features: ["Estrutura reticulada vazada futurista de alta resist\u00eancia", "Base circular est\u00e1vel com logo aranha e p\u00e9s antiderrapantes", "Encaixe universal compat\u00edvel com todos os modelos de headset", "Visual espetacular iluminado pelo reflexo do monitor gamer"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true,
  },
  {
    id: 'suporte-lata-garra-de-dragao-monster-dracan',
    name: "Suporte de Lata Garra de Drag\u00e3o Porta-Lata Monster 3D (Dracan)",
    category: 'geek',
    price: 70.00,
    originalPrice: 95.00,
    image: '/assets/products/suporte-lata-garra-dragao-monster.png',
    gallery: ["/assets/products/suporte-lata-garra-dragao-monster.png"],
    description: "Libere o poder drac\u00f4nico no seu setup! Caneca canelada \u00e9pica em formato de couro de escamas de drag\u00e3o negro com al\u00e7a esculpida em asa e garra drac\u00f4nica. O interior comporta perfeitamente a lata de Monster ou lat\u00f5es de cerveja, isolando a temperatura e transformando sua bebida em um artefato lend\u00e1rio de RPG.",
    features: ["Novo design preto mate refor\u00e7ado com textura de escamas draconianas", "Al\u00e7a anat\u00f4mica pesada em garra de drag\u00e3o com pegada firme", "Isolamento t\u00e9rmico que retarda o aquecimento da bebida", "Pe\u00e7a de destaque supremo para streamers, gamers e mesas de RPG"],
    material: 'PETG Resistente',
    inStock: true,
    isNew: true,
    bestSeller: true,
  },
  {
    id: 'castical-gotico-abobora-zucca-15cm',
    name: "Porta Velas Casti\u00e7al G\u00f3tico Ab\u00f3bora Zucca 15cm 3D",
    category: 'decoracao',
    price: 79.00,
    originalPrice: 105.00,
    image: '/assets/products/castical-gotico-abobora-zucca.png',
    gallery: ["/assets/products/castical-gotico-abobora-zucca.png"],
    description: "Casti\u00e7al escultural barroco-g\u00f3tico com 15 cm de altura, composto por espirais g\u00f3ticas entrela\u00e7adas, ornatos cl\u00e1ssicos e uma ab\u00f3bora sombria estilizada. O bocal superior acomoda velas palito tradicionais ou velas LED c\u00f4nicas com total firmeza e seguran\u00e7a.",
    features: ["15 cm de altura com centro de gravidade rebaixado anti-tombamento", "Detalhes barrocos rendados de alt\u00edssima defini\u00e7\u00e3o 3D", "Acabamento preto carv\u00e3o fosco medieval", "Cria uma atmosfera intimista, acolhedora e cinematogr\u00e1fica \u00e0 luz de velas"],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
  },
  {
    id: 'porta-canetas-chapeu-seletor-harry-potter',
    name: "Porta Canetas Chap\u00e9u Seletor Harry Potter 3D (PETG)",
    category: 'geek',
    price: 30.00,
    originalPrice: 99.00,
    image: '/assets/products/porta-canetas-chapeu-seletor.png',
    gallery: ["/assets/products/porta-canetas-chapeu-seletor.png"],
    description: "O lend\u00e1rio Chap\u00e9u Seletor das 4 casas de Hogwarts (Grifin\u00f3ria, Sonserina, Corvinal e Lufa-Lufa) esculpido com fidelidade cinematogr\u00e1fica. Apresenta todas as dobras expressivas do rosto, textura rugosa que simula couro envelhecido e ampla cavidade superior para canetas, pinc\u00e9is, varetas ou ferramentas de mesa.",
    features: ["Fabricado em PETG de alta durabilidade e densidade", "Textura realista e dobras expressivas id\u00eanticas aos filmes", "Cavidade profunda que suporta dezenas de canetas com estabilidade", "Item premium para colecionadores e f\u00e3s do universo bruxo"],
    material: 'PETG Resistente',
    inStock: true,
    isNew: true,
    bestSeller: true,
  },
  {
    id: 'suporte-paginas-livro-apoio-dedo',
    name: '2 Suporte páginas livro - Apoio Suporte Segurar com Dedo 3D',
    category: 'utilidades',
    price: 20.00,
    originalPrice: 28.00,
    image: '/assets/products/suporte-paginas-livro.png',
    gallery: ['/assets/products/suporte-paginas-livro.png'],
    description: 'Conjunto com 2 suportes anatômicos de polegar para leitura confortável com apenas uma mão. Permite manter o livro totalmente aberto sem cansar a mão e sem danificar as páginas, ideal para estudos, leitura na cama ou transporte.',
    features: [
      'Preço especial: R$ 20,00 (Par com 2 unidades)',
      'Design ergonômico em asas que abrem as duas páginas suavemente',
      'Orifício central com bordas arredondadas e toque aveludado',
      'Leve, compacto e fácil de transportar dentro do livro ou estojo',
      'Produzido em PLA Premium resistente de alta durabilidade'
    ],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true
  },
  {
    id: 'mini-jesus-decorativo-monitor-notebook',
    name: '2X Mini Jesus Decorativo Para Monitor e Notebook 3D',
    category: 'religioso',
    price: 20.00,
    originalPrice: 29.00,
    image: '/assets/products/mini-jesus-monitor-notebook.png',
    gallery: ['/assets/products/mini-jesus-monitor-notebook.png'],
    description: 'Conjunto com 2 miniaturas esculturais de Jesus Cristo projetadas com apoio especial para ficarem sentadas na borda superior de telas de monitores, notebooks, prateleiras e portas, abençoando seu dia a dia.',
    features: [
      'Preço do conjunto: R$ 20,00 (2 unidades)',
      'Encaixe equilibrado e seguro para bordas finas de monitores e laptops',
      'Detalhes esculturais delicados com túnica e expressão acolhedora',
      'Acabamento branco pérola suave em alta resolução 3D',
      'Lembrança e presente inspirador para mesa de trabalho e estudo'
    ],
    material: 'PLA Premium',
    inStock: true,
    isNew: true,
    bestSeller: true
  }
];

export const COMPANY_INFO = {
  name: 'Next Grid Store',
  tagline: 'Catálogo de Produtos em Impressão 3D',
  whatsappNumber: '5512991495308',
  whatsappFormatted: '(12) 99149-5308',
  instagramHandle: '@nextgridstore',
  directOrderHours: 'Segunda a Sábado, das 09h às 19h',
  shipmentNotice: 'O frete deverá ser verificado na hora da compra com base no seu CEP.',
  pixDiscountPercent: 5,
};
