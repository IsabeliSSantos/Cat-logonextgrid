import React from 'react';
import { Search, X, SlidersHorizontal, ArrowUpDown, FileText } from 'lucide-react';
import { CATEGORIES, PRODUCTS } from '../data/products';
import { ProductCategory } from '../types';

interface CategoryNavProps {
  activeCategory: ProductCategory;
  onSelectCategory: (category: ProductCategory) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  sortBy: 'relevancia' | 'menor_preco' | 'maior_preco';
  onSortChange: (sort: 'relevancia' | 'menor_preco' | 'maior_preco') => void;
  priceFilter: 'all' | 'under25' | '25to50' | 'above50';
  onPriceFilterChange: (filter: 'all' | 'under25' | '25to50' | 'above50') => void;
  totalFilteredCount: number;
  onOpenPdfModal?: () => void;
}

export const CategoryNav: React.FC<CategoryNavProps> = ({
  activeCategory,
  onSelectCategory,
  searchQuery,
  onSearchChange,
  sortBy,
  onSortChange,
  priceFilter,
  onPriceFilterChange,
  totalFilteredCount,
  onOpenPdfModal,
}) => {
  return (
    <div className="bg-slate-900/60 border-b border-slate-800 py-4 sm:py-6">
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 space-y-4 sm:space-y-5">
        {/* Search & Sort Controls Row */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 sm:gap-4">
          {/* Search Box */}
          <div className="relative flex-1 max-w-lg">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Buscar por enfeite de natal, kit, nossa senhora, suporte..."
              className="w-full bg-slate-950/80 border border-slate-700/80 rounded-lg pl-10 pr-9 py-2 sm:py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-400 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-colors"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white cursor-pointer"
                aria-label="Limpar busca"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Right Side: Price Range & Sort Order */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            {/* Price Filter Segment */}
            <div className="flex items-center gap-1 bg-slate-950/80 border border-slate-800 p-1 rounded-lg text-xs overflow-x-auto no-scrollbar max-w-full">
              <span className="text-slate-400 px-1.5 sm:px-2 py-1 flex items-center gap-1 font-medium shrink-0">
                <SlidersHorizontal className="w-3 h-3 text-cyan-400" />
                <span className="hidden xs:inline">Preço:</span>
              </span>
              <button
                onClick={() => onPriceFilterChange('all')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  priceFilter === 'all'
                    ? 'bg-cyan-600 text-white font-medium shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Todos
              </button>
              <button
                onClick={() => onPriceFilterChange('under25')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  priceFilter === 'under25'
                    ? 'bg-cyan-600 text-white font-medium shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                Até R$ 25
              </button>
              <button
                onClick={() => onPriceFilterChange('25to50')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  priceFilter === '25to50'
                    ? 'bg-cyan-600 text-white font-medium shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                R$ 25 - R$ 50
              </button>
              <button
                onClick={() => onPriceFilterChange('above50')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  priceFilter === 'above50'
                    ? 'bg-cyan-600 text-white font-medium shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                R$ 50+
              </button>
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-1 bg-slate-950/80 border border-slate-800 rounded-lg px-2.5 py-1 text-xs">
              <ArrowUpDown className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <select
                value={sortBy}
                onChange={(e) => onSortChange(e.target.value as any)}
                aria-label="Ordenar produtos"
                className="bg-transparent text-slate-200 py-1 focus:outline-none cursor-pointer"
              >
                <option value="relevancia" className="bg-slate-900 text-slate-100">Mais Relevantes</option>
                <option value="menor_preco" className="bg-slate-900 text-slate-100">Menor Preço</option>
                <option value="maior_preco" className="bg-slate-900 text-slate-100">Maior Preço</option>
              </select>
            </div>

            {/* PDF Export Button */}
            {onOpenPdfModal && (
              <button
                onClick={onOpenPdfModal}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-950/60 hover:bg-cyan-900/60 text-cyan-300 hover:text-cyan-200 border border-cyan-800/60 text-xs font-medium transition-colors cursor-pointer"
                title="Extrair Catálogo Completo em PDF"
              >
                <FileText className="w-3.5 h-3.5 text-cyan-400" />
                <span className="hidden sm:inline">Baixar</span> Catálogo PDF
              </button>
            )}
          </div>
        </div>

        {/* Categories Tab Bar */}
        <div className="overflow-x-auto no-scrollbar -mx-3 px-3 sm:mx-0 sm:px-0 pb-1">
          <div className="flex items-center gap-1.5 sm:gap-2 min-w-max">
            {CATEGORIES.map((category) => {
              const isActive = activeCategory === category.id;
              const count =
                category.id === 'todos'
                  ? PRODUCTS.length
                  : PRODUCTS.filter(
                      (p) =>
                        p.category === category.id ||
                        (category.id === 'decoracao' && p.id === 'bandeja-canelada-oval-3d') ||
                        (category.id === 'geek' && p.id === 'kit-9-enfeites-natal-harry-potter-3d') ||
                        (category.id === 'kits' && p.id === 'kit-9-enfeites-natal-harry-potter-3d')
                    ).length;

              return (
                <button
                  key={category.id}
                  onClick={() => onSelectCategory(category.id as ProductCategory)}
                  className={`px-3 py-1.5 sm:px-4 sm:py-2 rounded-lg text-xs sm:text-sm font-medium transition-all duration-150 flex items-center gap-1.5 sm:gap-2 cursor-pointer ${
                    isActive
                      ? 'bg-cyan-500 text-slate-950 font-bold shadow-[0_0_15px_rgba(6,182,212,0.25)]'
                      : 'bg-slate-950/60 hover:bg-slate-800/80 text-slate-300 hover:text-white border border-slate-800/80'
                  }`}
                >
                  <span>{category.label}</span>
                  <span
                    className={`text-[10px] sm:text-xs px-1.5 py-0.2 rounded font-mono tabular-nums ${
                      isActive ? 'bg-slate-950/30 text-slate-950' : 'bg-slate-800 text-slate-400'
                    }`}
                  >
                    {count}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Active Filter Status & Count */}
        <div className="flex items-center justify-between text-xs text-slate-400 pt-1">
          <div className="flex items-center gap-2">
            <span>Mostrando <strong className="text-white font-mono">{totalFilteredCount}</strong> produtos encontrados</span>
            {searchQuery && (
              <>
                <span aria-hidden="true">·</span>
                <span>Filtrado por: <em className="text-cyan-400 not-italic">"{searchQuery}"</em></span>
              </>
            )}
            {priceFilter !== 'all' && (
              <>
                <span aria-hidden="true">·</span>
                <span className="text-cyan-400 font-medium">
                  {priceFilter === 'under25' && 'Faixa: Até R$ 25'}
                  {priceFilter === '25to50' && 'Faixa: R$ 25 a R$ 50'}
                  {priceFilter === 'above50' && 'Faixa: Acima de R$ 50'}
                </span>
              </>
            )}
          </div>
          {(searchQuery || priceFilter !== 'all' || activeCategory !== 'todos') && (
            <button
              onClick={() => {
                onSearchChange('');
                onPriceFilterChange('all');
                onSelectCategory('todos');
              }}
              className="text-cyan-400 hover:underline hover:text-cyan-300 transition-colors"
            >
              Limpar todos os filtros
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
