import React, { useState, useEffect } from 'react';
import { X, Check, ShoppingBag, MessageCircle, Sparkles, Shield, Layers, Info, Truck } from 'lucide-react';
import { Product, CartItem } from '../types';
import { COMPANY_INFO } from '../data/products';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (item: Omit<CartItem, 'cartItemId'>) => void;
  onDirectWhatsApp: (message: string) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  onClose,
  onAddToCart,
  onDirectWhatsApp,
}) => {
  if (!product) return null;

  // Selected configurations
  const [selectedColor, setSelectedColor] = useState<string>(
    product.availableColors?.[0]?.name || ''
  );
  const [selectedOption, setSelectedOption] = useState<{ label: string; price: number }>(
    product.options?.choices?.[0] || { label: 'Padrão', price: product.price }
  );
  const [quantity, setQuantity] = useState<number>(1);
  const [showAddedAlert, setShowAddedAlert] = useState<boolean>(false);

  const [activeImage, setActiveImage] = useState<string>(product.image);

  // Reset or adjust state when product changes
  useEffect(() => {
    if (product) {
      setActiveImage(product.image);
      setSelectedColor(product.availableColors?.[0]?.name || '');
      setSelectedOption(
        product.options?.choices?.[0] || { label: 'Padrão', price: product.price }
      );
      setQuantity(1);
      setShowAddedAlert(false);
    }
  }, [product]);

  // Calculate effective unit price (with options or bulk discount)
  let unitPrice = selectedOption.price || product.price;
  if (product.bulkPrice && quantity >= product.bulkPrice.minQuantity) {
    unitPrice = product.bulkPrice.price;
  }
  const totalPrice = unitPrice * quantity;

  const handleAdd = () => {
    onAddToCart({
      product,
      quantity,
      selectedColor: selectedColor || undefined,
      selectedOption: product.options ? { name: selectedOption.label, price: selectedOption.price } : undefined,
      unitPrice,
    });
    setShowAddedAlert(true);
    setTimeout(() => {
      setShowAddedAlert(false);
      onClose();
    }, 1200);
  };

  const handleWhatsAppInquiry = () => {
    let text = `Olá Next Grid Store! Gostaria de informações sobre o produto do catálogo:\n*${product.name}*\n`;
    if (product.options) text += `• Modelo/Opção: ${selectedOption.label}\n`;
    if (selectedColor) text += `• Cor escolhida: ${selectedColor}\n`;
    text += `• Quantidade: ${quantity}\n`;
    text += `• Valor estimado: R$ ${totalPrice.toFixed(2).replace('.', ',')}\n`;
    text += `• Frete: A verificar com base no meu CEP.\n\nPoderiam calcular o frete e passar o prazo de entrega e chave Pix?`;
    onDirectWhatsApp(text);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div
        className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header bar */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800 bg-slate-950/60 shrink-0">
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-widest text-cyan-400 font-semibold">
              Detalhes do Produto
            </span>
            <span className="text-slate-600">/</span>
            <span className="text-xs text-slate-400">{product.material}</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Fechar modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body - Scrollable */}
        <div className="overflow-y-auto p-6 grid grid-cols-1 md:grid-cols-12 gap-8">
          {/* Left Column: Image showcase & Live Customizer Preview */}
          <div className="md:col-span-6 flex flex-col gap-4">
            <div className="relative aspect-square rounded-xl overflow-hidden bg-slate-950 border border-slate-800 group">
              <img
                src={activeImage}
                alt={product.name}
                className="w-full h-full object-cover transition-opacity duration-200"
                onError={(e) => {
                  const target = e.currentTarget;
                  if (target.src.includes('/public/assets/')) {
                    target.src = target.src.replace('/public/assets/', '/assets/');
                  }
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent opacity-40" />
            </div>

            {/* Gallery Thumbnails if multiple images exist */}
            {product.gallery && product.gallery.length > 1 && (
              <div className="flex items-center gap-2">
                {product.gallery.map((img, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => setActiveImage(img)}
                    className={`w-14 h-14 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${
                      activeImage === img
                        ? 'border-cyan-400 shadow-[0_0_10px_rgba(6,182,212,0.3)] scale-105'
                        : 'border-slate-800 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <img
                      src={img}
                      alt={`${product.name} vista ${idx + 1}`}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        const target = e.currentTarget;
                        if (target.src.includes('/public/assets/')) {
                          target.src = target.src.replace('/public/assets/', '/assets/');
                        }
                      }}
                    />
                  </button>
                ))}
              </div>
            )}

            {/* Technical Highlights */}
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-4 text-xs space-y-2.5">
              <div className="flex items-center justify-between text-slate-400 pb-2 border-b border-slate-800/60">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <Layers className="w-3.5 h-3.5 text-cyan-400" /> Material:
                </span>
                <span className="text-cyan-300 font-medium">{product.material}</span>
              </div>
              <div className="flex items-center justify-between text-slate-400 pb-2 border-b border-slate-800/60">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <Shield className="w-3.5 h-3.5 text-cyan-400" /> Tecnologia:
                </span>
                <span className="text-white">Impressão FDM multicamada 0.16mm</span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span className="flex items-center gap-1.5 text-slate-300">
                  <Truck className="w-3.5 h-3.5 text-cyan-400" /> Frete:
                </span>
                <span className="text-amber-300 font-medium text-[11px]">Verificado na hora da compra</span>
              </div>
            </div>
          </div>

          {/* Right Column: Title, Options, Custom Text & Purchase Module */}
          <div className="md:col-span-6 flex flex-col justify-between">
            <div className="space-y-4">
              <div>
                <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight leading-snug">
                  {product.name}
                </h2>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  {product.description}
                </p>
              </div>

              {/* Price display */}
              <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 flex items-center justify-between">
                <div>
                  <div className="text-[11px] text-slate-400">Valor Unitário</div>
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl font-bold text-white font-mono tabular-nums">
                      R$ {unitPrice.toFixed(2).replace('.', ',')}
                    </span>
                    {product.originalPrice && (
                      <span className="text-xs text-slate-500 line-through font-mono">
                        R$ {product.originalPrice.toFixed(2).replace('.', ',')}
                      </span>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-[11px] text-emerald-400 font-semibold block">
                    5% OFF à vista no Pix
                  </span>
                  {product.bulkPrice && (
                    <span className="text-[11px] text-cyan-300 font-mono">
                      Acima de 2 peças: R$ {product.bulkPrice.price.toFixed(2).replace('.', ',')}
                    </span>
                  )}
                </div>
              </div>

              {/* Choices / Composition Options if any */}
              {product.options && (
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-200 block">
                    {product.options.name}:
                  </label>
                  <div className="space-y-1.5">
                    {product.options.choices.map((choice) => (
                      <button
                        key={choice.label}
                        type="button"
                        onClick={() => setSelectedOption(choice)}
                        className={`w-full text-left p-2.5 rounded-lg border text-xs flex items-center justify-between transition-colors ${
                          selectedOption.label === choice.label
                            ? 'border-cyan-500 bg-cyan-950/30 text-white font-semibold'
                            : 'border-slate-800 bg-slate-950/40 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        <span>{choice.label}</span>
                        <span className="font-mono text-cyan-400">
                          R$ {choice.price.toFixed(2).replace('.', ',')}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Color options if available */}
              {product.availableColors && product.availableColors.length > 0 && (
                <div className="space-y-2">
                  <label className="text-xs font-semibold text-slate-200 flex items-center justify-between">
                    <span>Variação de Cor:</span>
                    <span className="text-cyan-400 font-normal text-[11px]">{selectedColor}</span>
                  </label>
                  <div className="grid grid-cols-2 gap-2">
                    {product.availableColors.map((color) => (
                      <button
                        key={color.name}
                        type="button"
                        onClick={() => setSelectedColor(color.name)}
                        className={`p-2 rounded-lg border text-xs flex items-center gap-2 transition-all ${
                          selectedColor === color.name
                            ? 'border-cyan-400 bg-cyan-950/40 text-white'
                            : 'border-slate-800 bg-slate-950/30 text-slate-400 hover:border-slate-700'
                        }`}
                      >
                        <span
                          className="w-3.5 h-3.5 rounded-full border border-white/20 shrink-0"
                          style={{ backgroundColor: color.hex }}
                        />
                        <span className="truncate">{color.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Features bullet list */}
              <div className="space-y-1 pt-1">
                <span className="text-xs font-semibold text-slate-300 block">Diferenciais:</span>
                <ul className="text-xs text-slate-400 space-y-1">
                  {product.features.map((feat, idx) => (
                    <li key={idx} className="flex items-center gap-2">
                      <span className="text-cyan-400">✓</span>
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Bottom Contiguous Purchase Module */}
            <div className="pt-5 border-t border-slate-800 mt-6 space-y-3">
              <div className="flex items-center justify-between">
                {/* Quantity stepper */}
                <div className="flex items-center border border-slate-700 rounded-lg bg-slate-950/80">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="px-3 py-1.5 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  >
                    -
                  </button>
                  <span className="px-3 py-1.5 text-xs font-mono font-bold text-white tabular-nums">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="px-3 py-1.5 text-slate-300 hover:text-white transition-colors cursor-pointer"
                  >
                    +
                  </button>
                </div>

                {/* Subtotal */}
                <div className="text-right">
                  <span className="text-[11px] text-slate-400 block">Subtotal dos itens</span>
                  <span className="text-lg font-bold text-cyan-400 font-mono tabular-nums">
                    R$ {totalPrice.toFixed(2).replace('.', ',')}
                  </span>
                </div>
              </div>

              {/* Shipping Notice */}
              <div className="bg-cyan-950/30 border border-cyan-800/40 rounded-lg p-2.5 text-[11px] text-cyan-200 flex items-center gap-2">
                <Truck className="w-4 h-4 text-cyan-400 shrink-0" />
                <span><strong>Aviso de Frete:</strong> O frete deverá ser verificado na hora da compra com base no seu CEP.</span>
              </div>

              {/* Action buttons */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <button
                  onClick={handleAdd}
                  className="w-full py-2.5 px-4 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-semibold text-sm transition-all duration-150 flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(6,182,212,0.25)] cursor-pointer"
                >
                  {showAddedAlert ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-300" />
                      <span>Adicionado!</span>
                    </>
                  ) : (
                    <>
                      <ShoppingBag className="w-4 h-4" />
                      <span>Adicionar ao Carrinho</span>
                    </>
                  )}
                </button>

                <button
                  onClick={handleWhatsAppInquiry}
                  className="w-full py-2.5 px-4 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white font-semibold text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>Pedir no WhatsApp</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
