import React, { useState } from 'react';
import { X, Trash2, Plus, Minus, MessageCircle, Sparkles, ArrowRight, ShieldCheck, Truck } from 'lucide-react';
import { CartItem } from '../types';
import { COMPANY_INFO } from '../data/products';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (cartItemId: string, newQty: number) => void;
  onRemoveItem: (cartItemId: string) => void;
  onClearCart: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
}) => {
  const [couponCode, setCouponCode] = useState<string>('');
  const [appliedDiscount, setAppliedDiscount] = useState<number>(0);
  const [couponFeedback, setCouponFeedback] = useState<string>('');
  const [clientAddressNote, setClientAddressNote] = useState<string>('');

  if (!isOpen) return null;

  // Calculate gross subtotal
  const grossSubtotal = items.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);
  const discountAmount = grossSubtotal * appliedDiscount;
  const netSubtotal = grossSubtotal - discountAmount;
  const pixTotal = netSubtotal * 0.95; // 5% discount on Pix

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    const clean = couponCode.trim().toUpperCase();
    if (clean === 'NEXTGRID10' || clean === 'PRIMEIRACOMPRA') {
      setAppliedDiscount(0.10);
      setCouponFeedback('Cupom de 10% aplicado com sucesso!');
    } else if (clean === 'NATAL5') {
      setAppliedDiscount(0.05);
      setCouponFeedback('Cupom de 5% aplicado com sucesso!');
    } else {
      setCouponFeedback('Cupom inválido. Tente PRIMEIRACOMPRA');
    }
  };

  const handleCheckoutWhatsApp = () => {
    let msg = `*NOVA ENCOMENDA - NEXT GRID STORE*\n\n`;
    msg += `Olá! Gostaria de confirmar o pedido dos seguintes itens do catálogo 3D:\n\n`;

    items.forEach((item, index) => {
      msg += `*${index + 1}. ${item.product.name}*\n`;
      msg += `   • Quantidade: ${item.quantity} un\n`;
      if (item.selectedOption) {
        msg += `   • Opção/Modelo: ${item.selectedOption.name}\n`;
      }
      if (item.selectedColor) {
        msg += `   • Cor: ${item.selectedColor}\n`;
      }
      msg += `   • Valor: R$ ${(item.unitPrice * item.quantity).toFixed(2).replace('.', ',')}\n\n`;
    });

    if (appliedDiscount > 0) {
      msg += `• Desconto Cupom (${appliedDiscount * 100}%): -R$ ${discountAmount.toFixed(2).replace('.', ',')}\n`;
    }
    msg += `*TOTAL ESTIMADO:* R$ ${netSubtotal.toFixed(2).replace('.', ',')} (ou R$ ${pixTotal.toFixed(2).replace('.', ',')} no Pix com 5% OFF)\n\n`;

    if (clientAddressNote.trim()) {
      msg += `*Dados de Envio/Entrega:* ${clientAddressNote.trim()}\n\n`;
    }

    msg += `*Frete:* O frete deverá ser verificado na hora da compra via CEP.\n`;
    msg += `Por favor, me informe o valor do frete e os dados do Pix para pagamento!`;

    const encoded = encodeURIComponent(msg);
    window.open(`https://wa.me/${COMPANY_INFO.whatsappNumber}?text=${encoded}`, '_blank');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/80 backdrop-blur-sm flex justify-end">
      <div
        className="w-full max-w-md bg-slate-900 border-l border-slate-800 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-slate-800 bg-slate-950/70 shrink-0">
          <div className="flex items-center gap-2">
            <h2 className="text-base font-bold text-white tracking-tight">
              Carrinho de Encomenda
            </h2>
            <span className="text-xs text-slate-400 font-mono">
              ({items.reduce((acc, i) => acc + i.quantity, 0)} itens)
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            aria-label="Fechar carrinho"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Drawer Content */}
        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center p-6 text-center">
            <div className="w-16 h-16 rounded-full bg-slate-800/80 flex items-center justify-center text-slate-500 mb-4">
              <Sparkles className="w-8 h-8 text-slate-500" />
            </div>
            <h3 className="text-base font-semibold text-slate-200 mb-1">
              Seu carrinho está vazio
            </h3>
            <p className="text-xs text-slate-400 max-w-xs mb-6">
              Navegue pelo nosso catálogo de Natal, kits decorativos e arte sacra para adicionar seus modelos 3D favoritos!
            </p>
            <button
              onClick={onClose}
              className="py-2 px-5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-xs transition-colors cursor-pointer"
            >
              Explorar Catálogo
            </button>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {items.map((item) => (
              <div
                key={item.cartItemId}
                className="p-3 bg-slate-950/70 border border-slate-800/80 rounded-xl flex gap-3 text-xs"
              >
                {/* Thumbnail */}
                <div className="w-16 h-16 rounded-lg overflow-hidden bg-slate-900 border border-slate-800 shrink-0">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Details */}
                <div className="flex-1 flex flex-col justify-between">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="font-semibold text-slate-200 line-clamp-1">
                        {item.product.name}
                      </h4>
                      {item.selectedOption && (
                        <div className="text-[11px] text-cyan-400">
                          {item.selectedOption.name}
                        </div>
                      )}
                      {item.selectedColor && (
                        <div className="text-[11px] text-slate-400">
                          Cor: {item.selectedColor}
                        </div>
                      )}
                    </div>
                    <button
                      onClick={() => onRemoveItem(item.cartItemId)}
                      className="text-slate-500 hover:text-rose-400 transition-colors p-1"
                      title="Remover item"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Quantity Stepper & Price */}
                  <div className="flex items-center justify-between pt-2 mt-1 border-t border-slate-800/50">
                    <div className="flex items-center border border-slate-700/80 rounded bg-slate-900">
                      <button
                        onClick={() => onUpdateQuantity(item.cartItemId, item.quantity - 1)}
                        className="px-2 py-0.5 text-slate-400 hover:text-white cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="px-2 font-mono font-semibold text-white">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onUpdateQuantity(item.cartItemId, item.quantity + 1)}
                        className="px-2 py-0.5 text-slate-400 hover:text-white cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <div className="text-right font-mono font-bold text-white tabular-nums">
                      R$ {(item.unitPrice * item.quantity).toFixed(2).replace('.', ',')}
                    </div>
                  </div>
                </div>
              </div>
            ))}

            {/* Coupon Code Input */}
            <form onSubmit={handleApplyCoupon} className="pt-2">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Cupom (ex: PRIMEIRACOMPRA)"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white uppercase placeholder-slate-500 focus:outline-none focus:border-cyan-500"
                />
                <button
                  type="submit"
                  className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200 transition-colors cursor-pointer"
                >
                  Aplicar
                </button>
              </div>
              {couponFeedback && (
                <div
                  className={`text-[11px] mt-1 ${
                    appliedDiscount > 0 ? 'text-emerald-400' : 'text-rose-400'
                  }`}
                >
                  {couponFeedback}
                </div>
              )}
            </form>

            {/* Delivery address / notes */}
            <div className="pt-1">
              <label className="text-[11px] text-slate-400 block mb-1">
                Cidade / CEP / Observações de Entrega:
              </label>
              <textarea
                value={clientAddressNote}
                onChange={(e) => setClientAddressNote(e.target.value)}
                placeholder="Ex: Envio para Campinas/SP - CEP 13000-000, ou detalhes dos nomes"
                rows={2}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 resize-none"
              />
            </div>
          </div>
        )}

        {/* Drawer Footer with Totals and Action Buttons */}
        {items.length > 0 && (
          <div className="p-4 bg-slate-950 border-t border-slate-800 space-y-3 shrink-0">
            {/* Notice regarding Shipping */}
            <div className="bg-cyan-950/40 border border-cyan-800/50 rounded-lg p-2.5 text-xs text-cyan-200 flex items-start gap-2.5">
              <Truck className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <div className="leading-snug">
                <span className="font-semibold block text-cyan-300">Aviso sobre o Frete:</span>
                <span>O frete deverá ser verificado na hora da compra via WhatsApp informando seu CEP.</span>
              </div>
            </div>

            {/* Totals Breakdown */}
            <div className="space-y-1 text-xs">
              <div className="flex justify-between text-slate-400">
                <span>Subtotal dos Produtos:</span>
                <span className="font-mono tabular-nums text-slate-200">
                  R$ {grossSubtotal.toFixed(2).replace('.', ',')}
                </span>
              </div>

              {appliedDiscount > 0 && (
                <div className="flex justify-between text-emerald-400">
                  <span>Desconto Cupom ({appliedDiscount * 100}%):</span>
                  <span className="font-mono tabular-nums">
                    - R$ {discountAmount.toFixed(2).replace('.', ',')}
                  </span>
                </div>
              )}

              <div className="flex justify-between text-slate-300 font-semibold pt-1 border-t border-slate-800">
                <span>Total Cartão:</span>
                <span className="font-mono tabular-nums text-white text-sm">
                  R$ {netSubtotal.toFixed(2).replace('.', ',')}
                </span>
              </div>

              {/* Pix highlight */}
              <div className="flex justify-between text-cyan-300 font-bold bg-cyan-950/40 p-2 rounded-lg border border-cyan-800/40">
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Preço com 5% OFF no Pix:</span>
                </span>
                <span className="font-mono tabular-nums text-base">
                  R$ {pixTotal.toFixed(2).replace('.', ',')}
                </span>
              </div>
            </div>

            {/* CTAs */}
            <div className="pt-1">
              <button
                onClick={handleCheckoutWhatsApp}
                className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/40 transition-colors cursor-pointer"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Enviar Pedido para WhatsApp</span>
              </button>
            </div>

            <div className="text-[10px] text-slate-400 text-center flex items-center justify-center gap-1 pt-1">
              <ShieldCheck className="w-3 h-3 text-cyan-400" />
              <span>Atendimento humanizado direto com o impressor 3D</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
