import React from 'react';
import { MessageCircle, Instagram, FileText } from 'lucide-react';
import { COMPANY_INFO } from '../data/products';
import { ProductCategory } from '../types';

interface FooterProps {
  onSelectCategory?: (cat: ProductCategory) => void;
  onOpenPdfModal?: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onSelectCategory, onOpenPdfModal }) => {
  return (
    <footer className="bg-slate-950 border-t border-slate-800 text-slate-400 text-xs mt-20">
      {/* Informational Columns */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {/* Brand Info */}
          <div className="space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg overflow-hidden border border-cyan-500/40 bg-slate-900">
                <img
                  src="/assets/aistudio/IMG_1693_b18f0a54.jpeg"
                  alt="Next Grid Store"
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="text-base font-bold text-white tracking-tight">
                NEXT GRID <span className="text-cyan-400 font-medium">STORE</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Especialistas em manufatura aditiva e impressão 3D de alta fidelidade. Decoração exclusiva, kits temáticos e projetos sob demanda.
            </p>
            <div className="flex items-center gap-3 pt-1">
              <a
                href={`https://wa.me/${COMPANY_INFO.whatsappNumber}`}
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-emerald-400 hover:border-emerald-500/50 transition-colors"
                aria-label="WhatsApp da Next Grid Store"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noreferrer"
                className="w-8 h-8 rounded-lg bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-300 hover:text-pink-400 hover:border-pink-500/50 transition-colors"
                aria-label="Instagram da Next Grid Store"
              >
                <Instagram className="w-4 h-4" />
              </a>
              {onOpenPdfModal && (
                <button
                  onClick={onOpenPdfModal}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-800 text-cyan-400 hover:text-white hover:border-cyan-500/50 text-[11px] font-medium transition-colors cursor-pointer"
                  title="Extrair Catálogo de Produtos em PDF"
                >
                  <FileText className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Baixar Catálogo PDF</span>
                </button>
              )}
            </div>
          </div>

          {/* 3D Printing Care & FAQ */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Cuidados com sua Peça 3D
            </h4>
            <ul className="space-y-1.5 text-[11px] leading-relaxed text-slate-400">
              <li>
                • <strong>Material PLA:</strong> Termoplástico de origem biológica sustentável (amido de milho). Evitar exposição prolongada ao sol intenso (acima de 55°C).
              </li>
              <li>
                • <strong>Limpeza:</strong> Use pano úmido ou detergente neutro. Não utilize produtos abrasivos ou água fervente.
              </li>
              <li>
                • <strong>Resistência:</strong> Nossas peças possuem paredes reforçadas e preenchimento de até 25% para máxima durabilidade.
              </li>
            </ul>
          </div>

          {/* Custom Orders & Contact */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">
              Atendimento & Dúvidas
            </h4>
            <p className="text-xs text-slate-400">
              Tem dúvidas sobre envio, cores ou quer consultar o frete para sua cidade?
            </p>
            <p className="text-[11px] text-cyan-300 font-medium bg-cyan-950/40 border border-cyan-800/40 rounded p-2">
              📦 <strong>Frete:</strong> O valor do frete deverá ser verificado na hora da compra com base no seu CEP.
            </p>
            <a
              href={`https://wa.me/${COMPANY_INFO.whatsappNumber}`}
              target="_blank"
              rel="noreferrer"
              className="py-2 px-3 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white transition-colors text-xs font-semibold cursor-pointer w-full text-center flex items-center justify-center gap-1.5"
            >
              <MessageCircle className="w-3.5 h-3.5" />
              <span>Chamar no WhatsApp: (12) 99149-5308</span>
            </a>
            <div className="text-[11px] text-slate-400 pt-1">
              Horário de Atendimento: {COMPANY_INFO.directOrderHours}
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 mt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-400">
          <p>© {new Date().getFullYear()} Next Grid Store. Todos os direitos reservados.</p>
          <div className="flex items-center gap-4">
            <span>Frete verificado na hora da compra</span>
            <span aria-hidden="true">·</span>
            <span>Envio Seguro para Todo o Brasil</span>
            <span aria-hidden="true">·</span>
            <span>Pagamento via Pix & Cartões</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
