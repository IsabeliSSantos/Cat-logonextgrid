import React, { useState } from 'react';
import {
  FileText,
  Download,
  Printer,
  X,
  CheckCircle,
  Sparkles,
  Layers,
  MessageCircle,
  HelpCircle,
} from 'lucide-react';
import { ProductCategory, Product } from '../types';
import { CATEGORIES, PRODUCTS, COMPANY_INFO } from '../data/products';
import { generateCatalogPdf } from '../utils/pdfGenerator';

interface PdfCatalogModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeCategory: ProductCategory;
}

export const PdfCatalogModal: React.FC<PdfCatalogModalProps> = ({
  isOpen,
  onClose,
  activeCategory,
}) => {
  const [selectedCat, setSelectedCat] = useState<ProductCategory>(activeCategory || 'todos');
  const [isGenerating, setIsGenerating] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);
  const [viewMode, setViewMode] = useState<'options' | 'printPreview'>('options');

  if (!isOpen) return null;

  const currentCategoryLabel =
    selectedCat === 'todos'
      ? 'Catálogo Completo (59 Produtos)'
      : CATEGORIES.find((c) => c.id === selectedCat)?.label || 'Categoria';

  const filteredProducts = PRODUCTS.filter((p) => {
    if (selectedCat === 'todos') return true;
    if (p.category === selectedCat) return true;
    if (selectedCat === 'decoracao' && p.id === 'bandeja-canelada-oval-3d') return true;
    if (selectedCat === 'geek' && p.id === 'kit-9-enfeites-natal-harry-potter-3d') return true;
    if (selectedCat === 'kits' && p.id === 'kit-9-enfeites-natal-harry-potter-3d') return true;
    return false;
  });

  const handleDownload = (cat: ProductCategory) => {
    setIsGenerating(true);
    setDownloadSuccess(false);

    setTimeout(() => {
      try {
        generateCatalogPdf({ category: cat });
        setDownloadSuccess(true);
        setTimeout(() => setDownloadSuccess(false), 3500);
      } catch (err) {
        console.error('Erro ao gerar PDF:', err);
      } finally {
        setIsGenerating(false);
      }
    }, 150);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div
        className={`bg-slate-900 border border-slate-700/80 rounded-2xl w-full shadow-2xl overflow-hidden flex flex-col transition-all duration-300 ${
          viewMode === 'printPreview'
            ? 'max-w-5xl max-h-[92vh]'
            : 'max-w-xl max-h-[90vh]'
        }`}
      >
        {/* Modal Header */}
        <div className="px-5 py-4 border-b border-slate-800 flex items-center justify-between bg-slate-950/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white flex items-center gap-2">
                Extrair Catálogo em PDF
                <span className="text-[10px] uppercase font-semibold tracking-wider px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  Imprimir / Salvar
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Gere o documento oficial com tabela de preços, fotos e especificações 3D.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Fechar"
            className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        {viewMode === 'options' ? (
          <div className="p-5 sm:p-6 space-y-6 overflow-y-auto">
            {/* Success message */}
            {downloadSuccess && (
              <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/40 text-emerald-200 text-xs flex items-center gap-2.5 animate-in slide-in-from-top-2 duration-200">
                <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  <strong>Download iniciado com sucesso!</strong> O arquivo PDF com preços e especificações foi salvo no seu dispositivo.
                </span>
              </div>
            )}

            {/* Scope Selection */}
            <div>
              <label className="text-xs font-semibold text-slate-300 uppercase tracking-wider block mb-2.5">
                1. Selecione o que deseja extrair:
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                {CATEGORIES.map((cat) => {
                  const isSel = selectedCat === cat.id;
                  const count =
                    cat.id === 'todos'
                      ? PRODUCTS.length
                      : PRODUCTS.filter((p) => p.category === cat.id).length;

                  return (
                    <button
                      key={cat.id}
                      onClick={() => setSelectedCat(cat.id as ProductCategory)}
                      className={`px-3 py-2.5 rounded-xl border text-xs font-medium text-left flex flex-col justify-between transition-all cursor-pointer ${
                        isSel
                          ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-[0_0_12px_rgba(6,182,212,0.2)]'
                          : 'bg-slate-950/40 border-slate-800 text-slate-300 hover:border-slate-700 hover:bg-slate-800/40'
                      }`}
                    >
                      <span className="font-semibold text-slate-200">{cat.label}</span>
                      <span className="text-[11px] text-cyan-400 mt-1">
                        {count} produtos
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Action 1: Quick Download PDF */}
            <div className="p-4 rounded-xl bg-slate-950/70 border border-slate-800 space-y-3">
              <div className="flex items-start justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-sm font-bold text-white">
                    <Download className="w-4 h-4 text-cyan-400" />
                    <span>Download Direto do PDF ({currentCategoryLabel})</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Gera instantaneamente um arquivo <strong>.pdf</strong> leve, limpo e profissional pronto para enviar aos clientes pelo WhatsApp ou imprimir.
                  </p>
                </div>
              </div>

              <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-1">
                <button
                  onClick={() => handleDownload(selectedCat)}
                  disabled={isGenerating}
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-semibold text-xs sm:text-sm transition-all duration-200 shadow-[0_0_18px_rgba(6,182,212,0.3)] hover:shadow-[0_0_24px_rgba(6,182,212,0.45)] cursor-pointer disabled:opacity-60"
                >
                  <Download className="w-4 h-4" />
                  <span>
                    {isGenerating
                      ? 'Processando Catálogo...'
                      : `Baixar PDF: ${currentCategoryLabel}`}
                  </span>
                </button>

                {selectedCat !== 'todos' && (
                  <button
                    onClick={() => handleDownload('todos')}
                    disabled={isGenerating}
                    className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs transition-colors border border-slate-700 cursor-pointer disabled:opacity-60"
                  >
                    Baixar Geral (Todos os 59)
                  </button>
                )}
              </div>
            </div>

            {/* Action 2: Visual Printable Catalog with Photos */}
            <div className="p-4 rounded-xl bg-slate-950/40 border border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-sm font-semibold text-slate-200">
                  <Printer className="w-4 h-4 text-purple-400" />
                  <span>Visualizar Catálogo com Fotos Ilustradas</span>
                </div>
                <p className="text-xs text-slate-400">
                  Abre uma visualização em grade com fotos nítidas dos produtos para imprimir ou salvar como PDF pelo próprio navegador.
                </p>
              </div>
              <button
                onClick={() => setViewMode('printPreview')}
                className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-200 text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer"
              >
                Abrir Visualização
              </button>
            </div>

            {/* Information Tips */}
            <div className="rounded-xl bg-cyan-950/30 border border-cyan-800/40 p-3.5 text-xs text-cyan-200 flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <p className="font-semibold text-white">Dica para vendas pelo WhatsApp:</p>
                <p className="text-cyan-200/80 leading-relaxed">
                  O catálogo em PDF contém todos os nomes exatos, valores de varejo, desconto de 5% Pix e preços de atacado. Quando o cliente escolher pelo PDF, ele só precisa te enviar o nome do produto no WhatsApp!
                </p>
              </div>
            </div>
          </div>
        ) : (
          /* Visual Print Preview Mode */
          <div className="flex-1 flex flex-col overflow-hidden">
            {/* Toolbar for print mode */}
            <div className="px-5 py-3 bg-slate-950 border-b border-slate-800 flex items-center justify-between gap-3">
              <button
                onClick={() => setViewMode('options')}
                className="text-xs font-medium text-cyan-400 hover:underline cursor-pointer flex items-center gap-1"
              >
                ← Voltar para opções de download
              </button>
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrint}
                  className="px-3.5 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-sm transition-colors"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Imprimir / Salvar PDF</span>
                </button>
              </div>
            </div>

            {/* Printable Content Area */}
            <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-950/90 text-slate-100 print:bg-white print:text-black">
              {/* Header in preview */}
              <div className="border-b border-slate-800 pb-4 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                <div>
                  <h1 className="text-xl sm:text-2xl font-extrabold text-white">
                    NEXT GRID <span className="text-cyan-400">STORE</span>
                  </h1>
                  <p className="text-xs text-slate-400">
                    Catálogo Oficial de Peças em Impressão 3D · {currentCategoryLabel}
                  </p>
                </div>
                <div className="text-right text-xs text-slate-300">
                  <p className="font-semibold text-cyan-400">
                    WhatsApp: {COMPANY_INFO.whatsappFormatted}
                  </p>
                  <p className="text-[11px] text-slate-400">
                    5% OFF no Pix · {COMPANY_INFO.shipmentNotice}
                  </p>
                </div>
              </div>

              {/* Product Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 sm:gap-4">
                {filteredProducts.map((p) => (
                  <div
                    key={p.id}
                    className="bg-slate-900 border border-slate-800 rounded-xl overflow-hidden p-2.5 flex flex-col justify-between"
                  >
                    <div>
                      <div className="aspect-square rounded-lg overflow-hidden bg-slate-950 mb-2 border border-slate-800/80">
                        <img
                          src={p.image}
                          alt={p.name}
                          className="w-full h-full object-cover"
                          loading="lazy"
                        />
                      </div>
                      <h3 className="text-xs font-bold text-white line-clamp-2 leading-snug">
                        {p.name}
                      </h3>
                      <p className="text-[10px] text-slate-400 mt-0.5 line-clamp-1">
                        {p.material}
                      </p>
                    </div>

                    <div className="mt-2 pt-2 border-t border-slate-800/80 flex items-baseline justify-between">
                      <span className="text-xs font-bold text-white">
                        R$ {p.price.toFixed(2).replace('.', ',')}
                      </span>
                      <span className="text-[10px] text-emerald-400 font-semibold">
                        Pix: R$ {(p.price * 0.95).toFixed(2).replace('.', ',')}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Modal Footer */}
        <div className="px-5 py-3 border-t border-slate-800 bg-slate-950/60 flex items-center justify-between text-xs text-slate-400">
          <span>{PRODUCTS.length} produtos disponíveis no catálogo</span>
          <button
            onClick={onClose}
            className="px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors cursor-pointer"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};
