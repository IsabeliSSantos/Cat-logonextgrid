import { ShoppingBag, Sparkles, FileText } from 'lucide-react';
import { ProductCategory } from '../types';

interface HeaderProps {
  cartItemCount: number;
  cartTotal: number;
  onOpenCart: () => void;
  onSelectCategory: (cat: ProductCategory) => void;
  activeCategory: ProductCategory;
  onOpenPdfModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartItemCount,
  cartTotal,
  onOpenCart,
  onSelectCategory,
  activeCategory,
  onOpenPdfModal,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800">
      {/* Promotional Top Bar */}
      <div className="bg-gradient-to-r from-cyan-950 via-slate-900 to-blue-950 text-cyan-200 text-[11px] sm:text-xs py-1.5 px-3 sm:px-4 text-center border-b border-cyan-900/40">
        <div className="max-w-7xl mx-auto flex items-center justify-center gap-1.5 sm:gap-2 font-medium leading-snug">
          <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0 hidden xs:inline" />
          <span>Next Grid Store · <strong>O frete deverá ser verificado na hora da compra</strong> · Envio Brasil · 5% OFF Pix</span>
        </div>
      </div>

      {/* Main Top Bar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 h-16 sm:h-18 flex items-center justify-between gap-3 sm:gap-8">
        {/* Zone 1: Brand wordmark & Logo */}
        <button
          onClick={() => onSelectCategory('todos')}
          className="flex items-center gap-2 sm:gap-3 text-left group shrink-0 focus:outline-none cursor-pointer"
        >
          <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg overflow-hidden border border-cyan-500/30 bg-slate-900 shadow-[0_0_15px_rgba(6,182,212,0.15)] flex items-center justify-center shrink-0">
            <img
              src="/assets/aistudio/IMG_1693_b18f0a54.jpeg"
              alt="Next Grid Store Logo"
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-200"
            />
          </div>
          <div className="flex flex-col">
            <span className="text-sm sm:text-base lg:text-lg font-bold tracking-tight text-white group-hover:text-cyan-300 transition-colors whitespace-nowrap">
              NEXT GRID <span className="text-cyan-400 font-medium">STORE</span>
            </span>
            <span className="text-[9px] sm:text-[10px] tracking-wider uppercase text-slate-400 whitespace-nowrap">
              Catálogo de Produtos 3D
            </span>
          </div>
        </button>

        {/* Zone 2: All 8 Catalog Categories Navigation Links */}
        <nav className="hidden xl:flex items-center gap-4 2xl:gap-5 text-xs 2xl:text-sm font-medium text-slate-300">
          <button
            onClick={() => onSelectCategory('todos')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer hover:text-cyan-400 ${
              activeCategory === 'todos' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400' : ''
            }`}
          >
            Catálogo Completo
          </button>
          <button
            onClick={() => onSelectCategory('natal')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer hover:text-cyan-400 ${
              activeCategory === 'natal' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400' : ''
            }`}
          >
            Coleção de Natal
          </button>
          <button
            onClick={() => onSelectCategory('anime')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer hover:text-cyan-400 ${
              activeCategory === 'anime' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400' : ''
            }`}
          >
            Anime & Mangá
          </button>
          <button
            onClick={() => onSelectCategory('kits')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer hover:text-cyan-400 ${
              activeCategory === 'kits' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400' : ''
            }`}
          >
            Kits & Combos
          </button>
          <button
            onClick={() => onSelectCategory('religioso')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer hover:text-cyan-400 ${
              activeCategory === 'religioso' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400' : ''
            }`}
          >
            Arte Sacra & Religioso
          </button>
          <button
            onClick={() => onSelectCategory('decoracao')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer hover:text-cyan-400 ${
              activeCategory === 'decoracao' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400' : ''
            }`}
          >
            Decoração & Casa
          </button>
          <button
            onClick={() => onSelectCategory('geek')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer hover:text-cyan-400 ${
              activeCategory === 'geek' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400' : ''
            }`}
          >
            Geek & Games
          </button>
          <button
            onClick={() => onSelectCategory('utilidades')}
            className={`whitespace-nowrap transition-colors py-1 cursor-pointer hover:text-cyan-400 ${
              activeCategory === 'utilidades' ? 'text-cyan-400 font-semibold border-b-2 border-cyan-400' : ''
            }`}
          >
            Utilidades & Mesa
          </button>
        </nav>

        {/* Zone 3: Actions (PDF Catalog & Shopping Cart) */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          <button
            onClick={onOpenPdfModal}
            aria-label="Extrair Catálogo em PDF"
            className="flex items-center gap-1.5 sm:gap-2 px-3 sm:px-3.5 py-2 rounded-lg bg-slate-900/90 hover:bg-slate-800 text-cyan-300 hover:text-white border border-cyan-500/30 hover:border-cyan-400 font-medium text-xs sm:text-sm transition-all duration-150 shadow-[0_0_12px_rgba(6,182,212,0.12)] whitespace-nowrap cursor-pointer"
            title="Extrair Catálogo em PDF"
          >
            <FileText className="w-4 h-4 text-cyan-400" />
            <span className="hidden xs:inline">Catálogo PDF</span>
          </button>

          <button
            onClick={onOpenCart}
            aria-label="Abrir carrinho de compras"
            className="flex items-center gap-2.5 px-3.5 sm:px-4 py-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-medium text-sm transition-all duration-150 shadow-[0_0_20px_rgba(6,182,212,0.25)] hover:shadow-[0_0_25px_rgba(6,182,212,0.4)] whitespace-nowrap cursor-pointer"
          >
            <div className="relative">
              <ShoppingBag className="w-4 h-4" />
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-rose-500 text-white text-[10px] font-bold rounded-full w-4 h-4 flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </div>
            <span className="hidden sm:inline">Carrinho</span>
            {cartTotal > 0 && (
              <span className="text-xs bg-cyan-700/60 px-1.5 py-0.5 rounded font-mono tabular-nums">
                R$ {cartTotal.toFixed(2).replace('.', ',')}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* Responsive Category Bar for Mobile / Tablets */}
      <div className="xl:hidden border-t border-slate-800/60 bg-slate-950/70 overflow-x-auto no-scrollbar px-4 py-2">
        <div className="flex items-center gap-1.5 min-w-max">
          <button
            onClick={() => onSelectCategory('todos')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeCategory === 'todos'
                ? 'bg-cyan-500 text-slate-950 font-semibold'
                : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            Catálogo
          </button>
          <button
            onClick={() => onSelectCategory('natal')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeCategory === 'natal'
                ? 'bg-cyan-500 text-slate-950 font-semibold'
                : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            Natal & Festas
          </button>
          <button
            onClick={() => onSelectCategory('anime')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeCategory === 'anime'
                ? 'bg-cyan-500 text-slate-950 font-semibold'
                : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            Anime & Mangá
          </button>
          <button
            onClick={() => onSelectCategory('kits')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeCategory === 'kits'
                ? 'bg-cyan-500 text-slate-950 font-semibold'
                : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            Kits & Combos
          </button>
          <button
            onClick={() => onSelectCategory('religioso')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeCategory === 'religioso'
                ? 'bg-cyan-500 text-slate-950 font-semibold'
                : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            Arte Sacra
          </button>
          <button
            onClick={() => onSelectCategory('decoracao')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeCategory === 'decoracao'
                ? 'bg-cyan-500 text-slate-950 font-semibold'
                : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            Decoração
          </button>
          <button
            onClick={() => onSelectCategory('geek')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeCategory === 'geek'
                ? 'bg-cyan-500 text-slate-950 font-semibold'
                : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            Geek & Games
          </button>
          <button
            onClick={() => onSelectCategory('utilidades')}
            className={`px-2.5 py-1 rounded-md text-xs font-medium whitespace-nowrap transition-colors cursor-pointer ${
              activeCategory === 'utilidades'
                ? 'bg-cyan-500 text-slate-950 font-semibold'
                : 'bg-slate-900 text-slate-300 hover:text-white border border-slate-800'
            }`}
          >
            Utilidades
          </button>
        </div>
      </div>
    </header>
  );
};
