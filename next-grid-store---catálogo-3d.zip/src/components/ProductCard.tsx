import React from 'react';
import { Plus, Sparkles, SlidersHorizontal, Check } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onOpenDetail: (product: Product) => void;
  onQuickAdd: (product: Product) => void;
  isAddedJustNow?: boolean;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  onOpenDetail,
  onQuickAdd,
  isAddedJustNow = false,
}) => {
  const categoryLabels: Record<string, string> = {
    natal: 'Coleção de Natal',
    anime: 'Anime & Mangá',
    kits: 'Kit & Combo',
    religioso: 'Arte Sacra',
    decoracao: 'Decoração',
    geek: 'Geek & Setup',
    utilidades: 'Utilidades',
  };

  return (
    <div className="group relative flex flex-col bg-slate-900/70 border border-slate-800 hover:border-cyan-500/50 rounded-xl overflow-hidden transition-all duration-200 hover:-translate-y-1 hover:shadow-xl hover:shadow-cyan-950/20">
      {/* Clickable Image Container */}
      <div
        onClick={() => onOpenDetail(product)}
        className="relative aspect-[4/3] bg-slate-950 overflow-hidden cursor-pointer"
      >
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
          onError={(e) => {
            const target = e.currentTarget;
            if (target.src.includes('/public/assets/')) {
              target.src = target.src.replace('/public/assets/', '/assets/');
            }
          }}
        />

        {/* Subtle Gradient Scrim for contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/70 via-transparent to-transparent opacity-60 group-hover:opacity-40 transition-opacity" />

        {/* Top Floating Trust / Discount Tag */}
        <div className="absolute top-3 left-3 flex flex-col gap-1 items-start">
          {product.bestSeller && (
            <span className="text-[11px] font-semibold tracking-wide uppercase px-2 py-0.5 rounded bg-amber-500/90 text-slate-950 shadow-sm">
              Mais Vendido
            </span>
          )}
          {product.isNew && (
            <span className="text-[11px] font-semibold tracking-wide uppercase px-2 py-0.5 rounded bg-cyan-400 text-slate-950 shadow-sm">
              Novo
            </span>
          )}
        </div>

        {/* Material hint */}
        <div className="absolute bottom-2.5 left-3 text-[11px] text-slate-300 drop-shadow-md font-mono">
          {product.material}
        </div>
      </div>

      {/* Card Content Area */}
      <div className="flex-1 p-4 flex flex-col justify-between">
        <div>
          {/* Unboxed Metadata */}
          <div className="flex items-center gap-2 text-[11px] text-slate-400 uppercase tracking-wider mb-1.5 font-medium">
            <span>{categoryLabels[product.category] || product.category}</span>
          </div>

          {/* Product Title */}
          <h3
            onClick={() => onOpenDetail(product)}
            className="text-sm sm:text-base font-semibold text-slate-100 group-hover:text-cyan-300 transition-colors line-clamp-2 cursor-pointer leading-snug mb-2"
          >
            {product.name}
          </h3>

          <p className="text-xs text-slate-400 line-clamp-2 mb-3 leading-relaxed">
            {product.description}
          </p>
        </div>

        {/* Price & Action Module */}
        <div className="pt-3 border-t border-slate-800/80 mt-auto">
          {/* Price row */}
          <div className="flex items-baseline justify-between mb-3">
            <div>
              {product.originalPrice && (
                <span className="text-xs text-slate-500 line-through mr-1.5 font-mono tabular-nums">
                  R$ {product.originalPrice.toFixed(2).replace('.', ',')}
                </span>
              )}
              <span className="text-lg font-bold text-white font-mono tabular-nums tracking-tight">
                R$ {product.price.toFixed(2).replace('.', ',')}
              </span>
              <span className="text-[10px] text-emerald-400 ml-1.5 font-medium">
                5% OFF no Pix
              </span>
            </div>

            {product.bulkPrice && (
              <div className="text-[11px] text-cyan-300 font-mono text-right">
                R$ {product.bulkPrice.price.toFixed(2).replace('.', ',')} (2+ un)
              </div>
            )}
          </div>

          {/* Freight note */}
          <div className="text-[10px] text-slate-400 mb-2.5 flex items-center gap-1">
            <span className="text-cyan-400">📦</span>
            <span>Frete a verificar na hora da compra</span>
          </div>

          {/* Buttons */}
          <div className="flex items-center gap-2">
            {product.options ? (
              <button
                onClick={() => onOpenDetail(product)}
                className="flex-1 py-2 px-3 rounded-lg bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/40 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span>Ver Opções</span>
              </button>
            ) : (
              <>
                <button
                  onClick={() => onQuickAdd(product)}
                  disabled={isAddedJustNow}
                  className={`flex-1 py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    isAddedJustNow
                      ? 'bg-emerald-600 text-white'
                      : 'bg-cyan-600 hover:bg-cyan-500 text-white shadow-[0_0_15px_rgba(6,182,212,0.2)]'
                  }`}
                >
                  {isAddedJustNow ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Adicionado!</span>
                    </>
                  ) : (
                    <>
                      <Plus className="w-3.5 h-3.5" />
                      <span>Adicionar</span>
                    </>
                  )}
                </button>
                <button
                  onClick={() => onOpenDetail(product)}
                  className="py-2 px-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-medium border border-slate-700 transition-colors cursor-pointer"
                  title="Ver detalhes técnicos"
                >
                  Detalhes
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
