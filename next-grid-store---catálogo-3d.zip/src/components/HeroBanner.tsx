import { ArrowRight, ShieldCheck, Truck, Sparkles, Layers, Gift } from 'lucide-react';
import { ProductCategory } from '../types';

interface HeroBannerProps {
  onSelectCategory: (category: ProductCategory) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  onSelectCategory,
}) => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-slate-950 to-slate-950 border-b border-slate-800">
      {/* Background glow effects */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute top-20 right-1/4 w-96 h-96 bg-blue-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-8 sm:py-12 lg:py-16">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-12 items-center">
          {/* Left Column: Brand Statement & Action */}
          <div className="lg:col-span-7 flex flex-col justify-center">
            {/* Editorial kicker */}
            <div className="flex items-center gap-2 text-[11px] sm:text-xs font-semibold text-cyan-400 mb-2 tracking-wider uppercase">
              <span>Next Grid Store</span>
              <span aria-hidden="true">·</span>
              <span>Catálogo Oficial de Produtos 3D</span>
            </div>

            <h1 className="text-2xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight mb-3 text-balance">
              Catálogo de Produtos em <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400">Impressão 3D</span>
            </h1>

            <p className="text-xs sm:text-sm md:text-base text-slate-300 mb-5 sm:mb-6 max-w-xl leading-relaxed">
              Confira nossa linha completa com colecionáveis, enfeites de Natal, kits decorativos, esculturas e utilidades em impressão 3D. <strong className="text-cyan-300 font-medium">O valor do frete deverá ser verificado na hora da compra com base no seu CEP.</strong>
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5 sm:gap-3 mb-6">
              <button
                onClick={() => onSelectCategory('natal')}
                className="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs sm:text-sm transition-all duration-150 flex items-center justify-center gap-2 shadow-[0_0_20px_rgba(6,182,212,0.3)] cursor-pointer"
              >
                <span>Coleção de Natal</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => onSelectCategory('kits')}
                className="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-medium text-xs sm:text-sm border border-slate-700 transition-all duration-150 flex items-center justify-center gap-2 cursor-pointer"
              >
                <Gift className="w-4 h-4 text-cyan-400" />
                <span>Kits & Combos</span>
              </button>
            </div>

            {/* Simple Trust Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-5 border-t border-slate-800/80 text-xs text-slate-400">
              <div className="flex items-center gap-2">
                <Truck className="w-4 h-4 text-cyan-400 shrink-0" />
                <span title="Frete calculado e verificado no fechamento do pedido">Frete a verificar na compra</span>
              </div>
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Envio para Todo o Brasil</span>
              </div>
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>PLA Premium Ecológico</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>5% OFF no Pix</span>
              </div>
            </div>
          </div>

          {/* Right Column: Featured Christmas Card Preview */}
          <div className="lg:col-span-5">
            <div className="relative group rounded-2xl overflow-hidden border border-slate-800 bg-slate-900/80 shadow-2xl">
              {/* Highlight Tag */}
              <div className="absolute top-4 left-4 z-10 bg-slate-950/80 backdrop-blur-md border border-cyan-500/40 text-cyan-300 text-xs px-3 py-1.5 rounded-md font-semibold flex items-center gap-1.5 shadow-lg">
                <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
                <span>Novidade de Natal</span>
              </div>

              {/* Showcase Image */}
              <div className="relative aspect-[4/3] overflow-hidden bg-slate-950">
                <img
                  src="/assets/aistudio/image_c0bc2387.png"
                  alt="Kit 9 Enfeites de Natal Mandalas Vazadas"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent" />
              </div>

              {/* Bottom Quick Info */}
              <div className="p-4">
                <div className="flex items-baseline justify-between mb-1.5">
                  <h2 className="text-base font-bold text-white group-hover:text-cyan-300 transition-colors">
                    Kit 9 Enfeites Mandalas Vazadas
                  </h2>
                  <div className="text-right">
                    <span className="text-xs text-slate-400 line-through mr-1.5 font-mono">R$ 35,00</span>
                    <span className="text-lg font-bold text-cyan-400 font-mono tabular-nums">R$ 25,00</span>
                  </div>
                </div>

                <p className="text-xs text-slate-400 line-clamp-2 mb-3">
                  Conjunto com 9 silhuetas natalinas vazadas: Presépio, Anjo, Árvore com presentes, Renas, Chalé e Trenó.
                </p>

                <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800">
                  <span>9 peças em Branco Neve</span>
                  <button
                    onClick={() => onSelectCategory('natal')}
                    className="text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
                  >
                    <span>Ver no catálogo</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
